const app = document.querySelector("#app");
const state = {
  user: null,
  data: null,
  studentAccounts: [],
  studentData: null,
  loginRole: "teacher",
  page: "dashboard",
  rosterView: "students",
  selectedClass: "",
  attendanceDate: localDateKey(new Date()),
  studentSearch: "",
  studentClassFilter: "all",
  classSearch: "",
  classGradeFilter: "all",
  attendanceFilter: "all",
  reportClass: "all",
  reportPeriod: 30,
  noticeType: "all",
  libraryCategory: "all",
  librarySearch: "",
  saving: false,
  studentNoticeType: "all",
};

function localDateKey(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[character]);
}

function initials(name) {
  return String(name).trim().split(/\s+/).slice(0, 2).map((part) => part[0] || "").join("").toUpperCase();
}

function studentLoginEmail(student) {
  const known = state.studentAccounts.find((account) => account.studentId === student.id);
  if (known) return known.email;
  const name = student.name.normalize("NFKD").replace(/[\u0300-\u036f]/g, "")
    .toLowerCase().replace(/[^a-z0-9]+/g, ".").replace(/^\.+|\.+$/g, "");
  return `${name}.${student.rollNumber}@students.campusone.edu`;
}

function className(classId) {
  const item = state.data.classes.find((entry) => entry.id === classId);
  return item ? `${item.grade} · ${item.name}` : "No class";
}

function classStudents(classId) {
  return state.data.students.filter((student) => student.classId === classId);
}

function statusFor(studentId, date = state.attendanceDate) {
  return state.data.attendance[date]?.[studentId] || "unmarked";
}

function dateLabel(date, options = { weekday: "short", month: "short", day: "numeric" }) {
  return new Intl.DateTimeFormat("en", options).format(new Date(`${date}T12:00:00`));
}

function feeAmount(amountPaise) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format(amountPaise / 100);
}

async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });
  let result;
  try { result = await response.json(); }
  catch { throw new Error("The server returned an unreadable response."); }
  if (!response.ok) throw new Error(result.error || "Something went wrong. Please try again.");
  return result;
}

function showLogin(error = "") {
  app.innerHTML = `
    <section class="login-screen">
      <div class="login-form-side">
        <div class="login-form-wrap">
          <div class="brand"><div class="brand-mark">C</div><div><span class="brand-name">Campus One</span><span class="brand-sub">Your campus, connected</span></div></div>
          <div class="login-role-switch" role="tablist" aria-label="Choose account type"><button class="login-role ${state.loginRole === "teacher" ? "active" : ""}" type="button" data-login-role="teacher" role="tab" aria-selected="${state.loginRole === "teacher"}">Faculty</button><button class="login-role ${state.loginRole === "student" ? "active" : ""}" type="button" data-login-role="student" role="tab" aria-selected="${state.loginRole === "student"}">Student</button></div>
          <p class="eyebrow">${state.loginRole === "student" ? "Student workspace" : "Faculty workspace"}</p>
          <h1>${state.loginRole === "student" ? "Good to see you." : "Welcome back."}</h1>
          <p class="login-intro">${state.loginRole === "student" ? "Check in on your attendance, explore the library, and see what you have borrowed." : "Your campus day, all in one place. Sign in to pick up where you left off."}</p>
          <form class="login-form" id="login-form">
            <div class="form-group"><label for="login-email">${state.loginRole === "student" ? "Student email" : "Email address"}</label><input id="login-email" name="email" type="email" autocomplete="username" placeholder="${state.loginRole === "student" ? "ava.thompson.01@students.campusone.edu" : "you@school.com"}" required></div>
            <div class="form-group"><label for="login-password">Password</label><input id="login-password" name="password" type="password" autocomplete="current-password" placeholder="Enter your password" required></div>
            <p class="login-error" role="alert">${escapeHtml(error)}</p>
            <button class="button login-submit" type="submit">Sign in <span aria-hidden="true">→</span></button>
          </form>
          <div class="demo-box"><div class="demo-box-title">${state.loginRole === "student" ? "Demo student account" : "Demo faculty account"}</div><div class="demo-creds"><strong>${state.loginRole === "student" ? "ava.thompson.01@students.campusone.edu" : "teacher@school.com"}</strong><strong>${state.loginRole === "student" ? "Student2026!" : "Attend2026!"}</strong></div>${state.loginRole === "student" ? '<p class="student-demo-note">Demo accounts share a starter password. Change it after signing in.</p>' : ""}</div>
        </div>
      </div>
      <aside class="login-art" aria-label="Illustration of the Campus One college building">
        <div class="art-orb"></div><div class="art-sun"></div>
        <div class="art-copy"><p class="eyebrow">A connected campus day</p><h2>Your campus life,<br>in one thoughtful place.</h2><p>Bring classes, campus notices, and the resources you need together—so there’s more room to learn.</p></div>
        <div class="art-scene campus-scene login-campus-scene" role="img" aria-label="A welcoming three-dimensional illustration of the Campus One college building"><div class="scene-sun"></div><div class="scene-cloud cloud-one"></div><div class="scene-cloud cloud-two"></div><div class="campus-tree tree-left"><i></i><i></i><b></b></div><div class="campus-building"><div class="building-roof"></div><div class="building-body"><div class="building-sign">CAMPUS ONE</div><div class="building-columns"><i></i><i></i><i></i><i></i><i></i></div><div class="building-entrance"></div><div class="building-windows"><i></i><i></i><i></i><i></i><i></i><i></i></div></div><div class="building-steps"></div></div><div class="campus-tree tree-right"><i></i><i></i><b></b></div><div class="campus-ground"></div></div>
        <div class="login-footnote">Campus One · Learn together, go further.</div>
      </aside>
    </section>`;

  app.querySelectorAll("[data-login-role]").forEach((button) => button.addEventListener("click", () => {
    state.loginRole = button.dataset.loginRole;
    showLogin();
  }));
  document.querySelector("#login-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const button = form.querySelector("button");
    const errorEl = form.querySelector(".login-error");
    button.disabled = true;
    button.textContent = "Signing in…";
    errorEl.textContent = "";
    try {
      const fields = new FormData(form);
      const result = await api(state.loginRole === "student" ? "/api/student/login" : "/api/login", {
        method: "POST",
        body: JSON.stringify({ email: fields.get("email"), password: fields.get("password") }),
      });
      state.user = result.user;
      if (state.loginRole === "student") await loadStudentPortal();
      else {
        state.user.role = "teacher";
        await loadPortal();
      }
    } catch (error) {
      errorEl.textContent = error.message;
      button.disabled = false;
      button.innerHTML = 'Sign in <span aria-hidden="true">→</span>';
    }
  });
}

function showStartupError(error) {
  app.innerHTML = `<section class="loading-screen"><div class="brand-mark">!</div><strong>We couldn’t connect to your classroom.</strong><span>${escapeHtml(error.message)}</span><button class="button" id="retry">Try again</button></section>`;
  document.querySelector("#retry").addEventListener("click", start);
}

async function start() {
  app.innerHTML = '<section class="loading-screen" aria-live="polite"><div class="brand-mark">C</div><span class="loading-dots">Opening your campus</span></section>';
  try {
    const result = await api("/api/me");
    state.user = result.user;
    state.user.role = "teacher";
    await loadPortal();
  } catch (error) {
    if (error.message !== "Not signed in.") {
      showStartupError(error);
      return;
    }
    try {
      const result = await api("/api/student/me");
      state.user = result.user;
      await loadStudentPortal();
    } catch (studentError) {
      if (studentError.message === "Not signed in.") showLogin();
      else showStartupError(studentError);
    }
  }
}

async function loadPortal() {
  try {
    const [data, accounts] = await Promise.all([api("/api/data"), api("/api/student/accounts")]);
    state.data = data;
    state.studentAccounts = accounts.accounts;
    state.studentData = null;
    if (!navigation.some((item) => item.id === state.page)) state.page = "dashboard";
    if (!state.selectedClass || !state.data.classes.some((item) => item.id === state.selectedClass)) {
      state.selectedClass = state.data.classes[0]?.id || "";
    }
    render();
  } catch (error) {
    if (error.message.includes("session has expired")) {
      state.user = null;
      showLogin(error.message);
    } else showStartupError(error);
  }
}

async function loadStudentPortal() {
  try {
    state.studentData = await api("/api/student/data");
    state.user = { ...state.studentData.student, role: "student" };
    if (!["student-home", "student-attendance", "student-books", "student-notices", "student-fees"].includes(state.page)) state.page = "student-home";
    render();
  } catch (error) {
    if (error.message.includes("session has expired")) {
      state.user = null;
      state.studentData = null;
      showLogin(error.message);
    } else showStartupError(error);
  }
}

const navigation = [
  { id: "dashboard", label: "Home", icon: "⌂" },
  { id: "attendance", label: "Attendance", icon: "✓" },
  { id: "students", label: "People", icon: "♧" },
  { id: "reports", label: "Reports", icon: "▥" },
  { id: "library", label: "Library", icon: "▤" },
  { id: "notices", label: "Notice board", icon: "▣" },
];

function navMarkup(mobile = false) {
  return navigation.map((item) => `<button class="nav-item ${state.page === item.id ? "active" : ""}" data-page="${item.id}" ${state.page === item.id ? 'aria-current="page"' : ""}><span class="nav-icon" aria-hidden="true">${item.icon}</span><span>${item.label}</span></button>`).join("");
}

function render() {
  if (state.user.role === "student") {
    renderStudentPortal();
    return;
  }
  app.innerHTML = `
    <div class="app-shell">
      <aside class="sidebar">
        <div class="brand"><div class="brand-mark">C</div><div><span class="brand-name">Campus One</span><span class="brand-sub">Your campus, connected</span></div></div>
        <div class="nav-caption">Campus</div><nav class="nav-list" aria-label="Main navigation">${navMarkup()}</nav>
        <div class="sidebar-bottom">
          <div class="side-note"><strong>Make today count</strong><p>Good things happen when a campus stays connected.</p></div>
          <div class="profile"><div class="avatar">${escapeHtml(initials(state.user.email.split("@")[0]))}</div><div class="profile-copy"><div class="profile-name">Faculty</div><div class="profile-email">${escapeHtml(state.user.email)}</div></div><button class="icon-button" data-action="logout" aria-label="Sign out" title="Sign out">↪</button></div>
        </div>
      </aside>
      <section class="main-area">
        <header class="topbar"><div class="breadcrumb">Campus One <span> / ${navigation.find((item) => item.id === state.page).label}</span></div><div class="topbar-right"><span class="today-label"><i class="topbar-dot"></i>${dateLabel(localDateKey(new Date()), { weekday: "long", month: "short", day: "numeric" })}</span></div></header>
        <main class="content" id="page-content">${pageMarkup()}</main>
      </section>
      <nav class="mobile-nav" aria-label="Main navigation">${navMarkup(true)}</nav>
    </div>
    <div id="overlay-root"></div>`;
  bindPageEvents();
}

const studentNavigation = [
  { id: "student-home", label: "My overview", icon: "⌂" },
  { id: "student-attendance", label: "Attendance", icon: "✓" },
  { id: "student-fees", label: "Fees", icon: "₹" },
  { id: "student-books", label: "My books", icon: "▤" },
  { id: "student-notices", label: "Notice board", icon: "▣" },
];

function studentRangeAttendance() {
  const start = new Date();
  start.setDate(start.getDate() - 29);
  const from = localDateKey(start);
  const records = state.studentData.attendance.filter((item) => item.date >= from);
  const attended = records.filter((item) => item.status === "present" || item.status === "late").length;
  return { records, attended, rate: records.length ? Math.round((attended / records.length) * 100) : 0 };
}

function studentPageMarkup() {
  if (state.page === "student-attendance") return studentAttendancePage();
  if (state.page === "student-fees") return studentFeesPage();
  if (state.page === "student-books") return studentBooksPage();
  if (state.page === "student-notices") return studentNoticesPage();
  return studentHomePage();
}

function renderStudentPortal() {
  const currentPage = studentNavigation.find((item) => item.id === state.page) || studentNavigation[0];
  app.innerHTML = `
    <div class="app-shell student-shell">
      <aside class="sidebar">
        <div class="brand"><div class="brand-mark">C</div><div><span class="brand-name">Campus One</span><span class="brand-sub">Student portal</span></div></div>
        <div class="nav-caption">My campus</div><nav class="nav-list" aria-label="Student navigation">${studentNavigation.map((item) => `<button class="nav-item ${state.page === item.id ? "active" : ""}" data-student-page="${item.id}" aria-current="${state.page === item.id ? "page" : "false"}"><span class="nav-icon" aria-hidden="true">${item.icon}</span><span>${item.label}</span></button>`).join("")}</nav>
        <div class="sidebar-bottom"><div class="side-note"><strong>Your campus, your journey</strong><p>Keep learning, keep showing up, and make the most of your time here.</p></div><div class="profile"><div class="avatar">${escapeHtml(initials(state.user.name))}</div><div class="profile-copy"><div class="profile-name">${escapeHtml(state.user.name)}</div><div class="profile-email">Student · ${escapeHtml(state.user.rollNumber)}</div></div><button class="icon-button" data-action="logout" aria-label="Sign out" title="Sign out">↪</button></div></div>
      </aside>
      <section class="main-area"><header class="topbar"><div class="breadcrumb">Campus One <span> / ${currentPage.label}</span></div><div class="topbar-right"><button class="text-action" data-action="change-password">Update password</button><span class="today-label"><i class="topbar-dot"></i>${dateLabel(localDateKey(new Date()), { weekday: "long", month: "short", day: "numeric" })}</span></div></header><main class="content" id="page-content">${studentPageMarkup()}</main></section>
      <nav class="mobile-nav" aria-label="Student navigation">${studentNavigation.map((item) => `<button class="nav-item ${state.page === item.id ? "active" : ""}" data-student-page="${item.id}"><span class="nav-icon" aria-hidden="true">${item.icon}</span><span>${item.label}</span></button>`).join("")}</nav>
    </div><div id="overlay-root"></div>`;
  app.querySelectorAll("[data-student-page]").forEach((button) => button.addEventListener("click", () => {
    state.page = button.dataset.studentPage;
    renderStudentPortal();
  }));
  app.querySelector('[data-action="logout"]').addEventListener("click", logout);
  app.querySelector('[data-action="change-password"]').addEventListener("click", showStudentPasswordDialog);
  app.querySelector("#student-notice-type-filter")?.addEventListener("change", (event) => {
    state.studentNoticeType = event.target.value;
    renderStudentPortal();
  });
  app.querySelector("#fee-invoice-select")?.addEventListener("change", (event) => {
    const invoice = state.studentData.feeInvoices.find((item) => item.id === event.target.value);
    const amountInput = app.querySelector("#fee-amount");
    if (invoice && amountInput) {
      amountInput.max = (invoice.amountPaise / 100).toFixed(2);
      amountInput.value = amountInput.max;
    }
  });
  app.querySelector("#fee-payment-form")?.addEventListener("submit", submitFeeSimulation);
  app.querySelectorAll("[data-issue-book]").forEach((button) => button.addEventListener("click", () => issueBook(button.dataset.issueBook)));
  app.querySelectorAll("[data-return-loan]").forEach((button) => button.addEventListener("click", () => returnBook(button.dataset.returnLoan)));
}

function studentHomePage() {
  const summary = studentRangeAttendance();
  const activeLoans = state.studentData.loans.filter((loan) => !loan.returnedAt);
  const recent = state.studentData.attendance.slice(0, 5);
  const rows = recent.map((record) => `<tr><td>${escapeHtml(dateLabel(record.date, { weekday: "short", month: "short", day: "numeric", year: "numeric" }))}</td><td>${statusPill(record.status)}</td></tr>`).join("");
  const dueSoon = activeLoans.filter((loan) => (new Date(loan.dueAt) - Date.now()) < 4 * 24 * 60 * 60 * 1000).length;
  return `<section class="student-welcome"><div><p class="eyebrow">YOUR CAMPUS JOURNEY</p><h1>Hi, ${escapeHtml(state.studentData.student.name.split(" ")[0])}.</h1><p>${escapeHtml(state.studentData.course.grade)} · ${escapeHtml(state.studentData.course.name)}<br>Your attendance, reading list, and borrowed books—all in one place.</p><button class="button" data-student-page="student-books">Find your next read <span aria-hidden="true">→</span></button></div><div class="student-welcome-art" aria-hidden="true"><div class="welcome-book book-one"></div><div class="welcome-book book-two"></div><div class="welcome-book book-three"></div><span>YOUR NEXT CHAPTER</span></div></section>
    <section class="metric-grid student-metrics" aria-label="My campus summary">${metricCard("Attendance · 30 days", summary.records.length ? `${summary.rate}%` : "—", `${summary.attended} of ${summary.records.length} marked sessions attended`, "✓")}${metricCard("Sessions recorded", summary.records.length, "In the last 30 days", "▦")}${metricCard("Books checked out", activeLoans.length, "Of 3 books you may borrow", "▤")}${metricCard("Due soon", dueSoon, dueSoon ? "Please return these in 4 days" : "All clear for now", "◷")}</section>
    <div class="student-dashboard-grid"><section class="table-panel"><div class="table-head"><div><h2>Recent attendance</h2><p class="section-sub">Your latest recorded check-ins</p></div><button class="button secondary small" data-student-page="student-attendance">Full history <span aria-hidden="true">→</span></button></div>${rows ? `<div class="table-wrap"><table><thead><tr><th>Date</th><th>Status</th></tr></thead><tbody>${rows}</tbody></table></div>` : emptyState("No attendance marked yet", "Your recent attendance will appear here.")}</section><section class="panel student-loan-peek"><div class="panel-heading"><div><h2>On your bookshelf</h2><p class="section-sub">Books you have checked out</p></div><button class="icon-button" data-student-page="student-books" aria-label="View my books">↗</button></div>${activeLoans.length ? activeLoans.slice(0, 3).map((loan) => { const book = state.studentData.books.find((item) => item.id === loan.bookId); return `<div class="student-loan-row"><span class="mini-book-cover"></span><span><strong>${escapeHtml(book?.title || "Library book")}</strong><small>Due ${escapeHtml(dateLabel(loan.dueAt.slice(0, 10), { month: "short", day: "numeric" }))}</small></span></div>`; }).join("") : emptyState("Your next read is waiting", "Borrow a book from the library.")}<button class="hero-link" data-student-page="student-books">Browse books <span aria-hidden="true">→</span></button></section></div>`;
}

function studentAttendancePage() {
  const summary = studentRangeAttendance();
  const rows = summary.records.map((record) => `<tr><td>${escapeHtml(dateLabel(record.date, { weekday: "short", month: "short", day: "numeric", year: "numeric" }))}</td><td>${statusPill(record.status)}</td></tr>`).join("");
  return `<div class="page-heading"><div><p class="eyebrow">Your learning rhythm</p><h1>My attendance</h1><p class="heading-sub">${escapeHtml(state.studentData.course.grade)} · ${escapeHtml(state.studentData.course.name)}</p></div></div><section class="report-summary student-attendance-summary"><article class="report-card"><div class="report-card-label">Attendance · last 30 days</div><div class="report-card-value">${summary.records.length ? `${summary.rate}%` : "—"}</div><div class="report-card-note">Present and late count as attended</div></article><article class="report-card"><div class="report-card-label">Present / late</div><div class="report-card-value">${summary.attended}</div><div class="report-card-note">Of ${summary.records.length} recorded sessions</div></article><article class="report-card"><div class="report-card-label">Absent</div><div class="report-card-value">${summary.records.filter((record) => record.status === "absent").length}</div><div class="report-card-note">In the last 30 days</div></article></section><section class="table-panel"><div class="table-head"><div><h2>Attendance history</h2><p class="section-sub">Your attendance records, newest first</p></div><span class="pill present">${summary.records.length} sessions</span></div>${rows ? `<div class="table-wrap"><table><thead><tr><th>Date</th><th>Your status</th></tr></thead><tbody>${rows}</tbody></table></div>` : emptyState("Your attendance history is clear", "Check back after your teacher records attendance.")}</section>`;
}

function studentBooksPage() {
  const activeLoans = state.studentData.loans.filter((loan) => !loan.returnedAt);
  const bookCards = state.studentData.books.map((book) => {
    const alreadyBorrowed = activeLoans.some((loan) => loan.bookId === book.id);
    return `<article class="student-book-card"><div class="student-book-cover"><span>CAMPUS ONE</span><strong>${escapeHtml(book.title)}</strong><small>${escapeHtml(book.author)}</small></div><div class="student-book-info"><span class="notice-type">${escapeHtml(book.genre)}</span><h2>${escapeHtml(book.title)}</h2><p>By ${escapeHtml(book.author)}</p><span class="book-stock">${book.availableCopies} ${book.availableCopies === 1 ? "copy" : "copies"} available</span><button class="button ${alreadyBorrowed ? "soft" : "secondary"} small" data-issue-book="${escapeHtml(book.id)}" ${alreadyBorrowed || book.availableCopies < 1 || activeLoans.length >= 3 ? "disabled" : ""}>${alreadyBorrowed ? "Already borrowed" : book.availableCopies < 1 ? "Currently unavailable" : "Issue this book"}</button></div></article>`;
  }).join("");
  const loanRows = state.studentData.loans.slice().sort((a, b) => b.issuedAt.localeCompare(a.issuedAt)).map((loan) => {
    const book = state.studentData.books.find((item) => item.id === loan.bookId);
    return `<tr><td><div class="student-cell"><span class="mini-book-cover"></span>${escapeHtml(book?.title || "Library book")}</div></td><td>${escapeHtml(dateLabel(loan.issuedAt.slice(0, 10), { month: "short", day: "numeric", year: "numeric" }))}</td><td>${loan.returnedAt ? '<span class="pill returned">Returned</span>' : `<span class="pill ${new Date(loan.dueAt) < Date.now() ? "absent" : "late"}">${new Date(loan.dueAt) < Date.now() ? "Overdue" : `Due ${escapeHtml(dateLabel(loan.dueAt.slice(0, 10), { month: "short", day: "numeric" }))}`}</span>`}</td><td>${loan.returnedAt ? "Returned" : `<button class="button secondary small" data-return-loan="${escapeHtml(loan.id)}">Return book</button>`}</td></tr>`;
  }).join("");
  return `<div class="page-heading"><div><p class="eyebrow">Find a story, borrow an idea</p><h1>Campus library</h1><p class="heading-sub">Issue a book and keep it for two weeks. You can have up to three out at a time.</p></div></div><section class="student-loans-panel"><div class="table-head"><div><h2>My checked-out books</h2><p class="section-sub">${activeLoans.length} of 3 active loans</p></div></div>${loanRows ? `<div class="table-wrap"><table><thead><tr><th>Title</th><th>Issued</th><th>Due</th><th>Action</th></tr></thead><tbody>${loanRows}</tbody></table></div>` : emptyState("Your bookshelf is ready", "Issue a book below to start a loan.")}</section><div class="library-section-heading"><div><h2>Available to borrow</h2><p class="section-sub">A little curiosity goes a long way.</p></div><span class="today-label">Select a title to issue it</span></div><section class="student-books-grid" aria-label="Books available for loan">${bookCards}</section>`;
}

function studentNoticesPage() {
  const allNotices = state.studentData.notices || [];
  const notices = allNotices.filter((notice) => state.studentNoticeType === "all" || notice.type === state.studentNoticeType);
  const noticeCards = notices.map((notice) => {
    const audience = notice.classId
      ? `${state.studentData.course.grade} · ${state.studentData.course.name}`
      : "All campus";
    return `<article class="notice-card"><div class="notice-card-top"><span class="notice-type ${escapeHtml(notice.type)}">${noticeTypeLabel(notice.type)}</span><time datetime="${escapeHtml(notice.createdAt)}">${escapeHtml(noticeTime(notice.createdAt))}</time></div><h2>${escapeHtml(notice.title)}</h2><p>${escapeHtml(notice.body)}</p><div class="notice-card-footer"><div class="notice-author"><span class="student-avatar">${escapeHtml(initials(notice.author))}</span><span>${escapeHtml(notice.author)}</span></div><span class="notice-audience">${escapeHtml(audience)}</span></div></article>`;
  }).join("");
  const emptyMessages = {
    all: ["No notices yet", "Campus announcements and class updates will appear here."],
    announcement: ["No announcements yet", "There are no announcements for your campus or class right now."],
    homework: ["No homework notices yet", "New class assignments will appear here when posted."],
    event: ["No events posted yet", "Check back here for upcoming campus events."],
    update: ["No campus updates yet", "Campus updates will appear here when shared."],
  };
  const [emptyTitle, emptyDescription] = emptyMessages[state.studentNoticeType];
  return `<div class="page-heading"><div><p class="eyebrow">Stay in the know</p><h1>Campus notice board</h1><p class="heading-sub">Events, announcements, homework, and updates for your class and campus.</p></div></div><div class="notice-toolbar"><div><span class="notice-online-dot"></span>Your campus updates <span class="notice-count">${notices.length} ${notices.length === 1 ? "post" : "posts"}</span></div><select class="select filter-select" id="student-notice-type-filter" aria-label="Filter campus notices"><option value="all" ${state.studentNoticeType === "all" ? "selected" : ""}>Everything</option><option value="announcement" ${state.studentNoticeType === "announcement" ? "selected" : ""}>Announcements</option><option value="homework" ${state.studentNoticeType === "homework" ? "selected" : ""}>Homework</option><option value="event" ${state.studentNoticeType === "event" ? "selected" : ""}>Events</option><option value="update" ${state.studentNoticeType === "update" ? "selected" : ""}>Campus updates</option></select></div><section class="notice-grid" aria-label="Notices for your campus and class">${noticeCards || emptyState(emptyTitle, emptyDescription)}</section>`;
}

function studentFeesPage() {
  const invoices = state.studentData.feeInvoices;
  const simulations = state.studentData.feePaymentSimulations.slice().sort((a, b) => b.submittedAt.localeCompare(a.submittedAt));
  const totalDue = invoices.reduce((sum, invoice) => sum + invoice.amountPaise, 0);
  const selectedInvoice = invoices[0];
  const invoiceRows = invoices.map((invoice) => {
    const overdue = new Date(`${invoice.dueDate}T23:59:59`) < Date.now();
    return `<tr><td><strong>${escapeHtml(invoice.title)}</strong><small class="fee-term">${escapeHtml(invoice.term)}</small></td><td>${escapeHtml(dateLabel(invoice.dueDate, { month: "short", day: "numeric", year: "numeric" }))}</td><td><span class="fee-due-status ${overdue ? "overdue" : ""}">${overdue ? "Overdue" : "Due"}</span></td><td class="fee-amount">${escapeHtml(feeAmount(invoice.amountPaise))}</td></tr>`;
  }).join("");
  const simulationRows = simulations.map((simulation) => {
    const invoice = invoices.find((item) => item.id === simulation.invoiceId);
    return `<tr><td><strong>${escapeHtml(invoice?.title || "Fee item")}</strong><small class="fee-term">${escapeHtml(simulation.reference)}</small></td><td>${escapeHtml(dateLabel(simulation.submittedAt.slice(0, 10), { month: "short", day: "numeric", year: "numeric" }))}</td><td class="fee-amount">${escapeHtml(feeAmount(simulation.amountPaise))}</td><td><span class="fee-simulation-status">Simulation only · not paid</span></td></tr>`;
  }).join("");
  const invoiceOptions = invoices.map((invoice) => `<option value="${escapeHtml(invoice.id)}">${escapeHtml(invoice.title)} · ${feeAmount(invoice.amountPaise)}</option>`).join("");
  return `<div class="page-heading"><div><p class="eyebrow">Your account, at a glance</p><h1>Fees & payments</h1><p class="heading-sub">Review your charges and try a clearly labeled payment simulation.</p></div></div>
    <aside class="student-fee-notice" aria-label="Payment simulation notice"><span aria-hidden="true">ⓘ</span><div><strong>Demo only · No real payment will be processed</strong><p>Submitting below records a simulation for demonstration. No card or bank details are collected, no money moves, and your balance will not change.</p></div></aside>
    <section class="report-summary student-fees-summary" aria-label="My fee summary"><article class="report-card"><div class="report-card-label">Outstanding balance</div><div class="report-card-value">${escapeHtml(feeAmount(totalDue))}</div><div class="report-card-note">Simulations do not reduce this balance</div></article><article class="report-card"><div class="report-card-label">Fee items</div><div class="report-card-value">${invoices.length}</div><div class="report-card-note">Charges on your account</div></article><article class="report-card"><div class="report-card-label">Payment simulations</div><div class="report-card-value">${simulations.length}</div><div class="report-card-note">Demo records · not actual payments</div></article></section>
    <div class="student-fees-layout"><section class="table-panel"><div class="table-head"><div><h2>Current charges</h2><p class="section-sub">Your full fee balance, grouped by item</p></div></div>${invoiceRows ? `<div class="table-wrap"><table><thead><tr><th>Fee item</th><th>Due date</th><th>Status</th><th>Balance</th></tr></thead><tbody>${invoiceRows}</tbody></table></div>` : emptyState("No fee items yet", "Your college has not added any charges to this account.")}</section>
    <section class="panel student-fee-payment-panel"><div class="panel-heading"><div><h2>Try a payment simulation</h2><p class="section-sub">Choose a fee and amount to create a demo record.</p></div></div>${selectedInvoice ? `<form id="fee-payment-form" class="student-fee-form"><div class="form-group"><label for="fee-invoice-select">Fee item</label><select id="fee-invoice-select" name="invoiceId">${invoiceOptions}</select></div><div class="form-group"><label for="fee-amount">Amount to simulate (INR)</label><input id="fee-amount" name="amount" type="number" min="0.01" max="${(selectedInvoice.amountPaise / 100).toFixed(2)}" step="0.01" value="${(selectedInvoice.amountPaise / 100).toFixed(2)}" required></div><button class="button" type="submit">Submit simulated payment</button></form>` : emptyState("No fee items to pay", "Your fee balance will appear here when charges are available.")}</section></div>
    <section class="table-panel student-fee-history"><div class="table-head"><div><h2>Payment status</h2><p class="section-sub">Every entry below is a simulation, not a processed payment.</p></div><span class="fee-simulation-status">DEMO ONLY</span></div>${simulationRows ? `<div class="table-wrap"><table><thead><tr><th>Fee item</th><th>Submitted</th><th>Amount</th><th>Status</th></tr></thead><tbody>${simulationRows}</tbody></table></div>` : emptyState("No payment simulations yet", "Demo submissions will appear here with a clear not-paid status.")}</section>`;
}

async function refreshStudentData() {
  state.studentData = await api("/api/student/data");
  state.user = { ...state.studentData.student, role: "student" };
  renderStudentPortal();
}

async function issueBook(bookId) {
  try {
    const result = await api("/api/student/loans", { method: "POST", body: JSON.stringify({ bookId }) });
    await refreshStudentData();
    toast(`Issued "${result.book.title}". It is due in two weeks.`);
  } catch (error) {
    toast(error.message, true);
  }
}

async function returnBook(loanId) {
  try {
    await api(`/api/student/loans/${encodeURIComponent(loanId)}/return`, { method: "POST", body: "{}" });
    await refreshStudentData();
    toast("Book returned. Thanks for keeping the library moving.");
  } catch (error) {
    toast(error.message, true);
  }
}

async function submitFeeSimulation(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const button = event.currentTarget.querySelector('button[type="submit"]');
  button.disabled = true;
  try {
    const response = await api("/api/student/fee-payments", {
      method: "POST",
      body: JSON.stringify({
        invoiceId: form.get("invoiceId"),
        amountPaise: Math.round(Number(form.get("amount")) * 100),
      }),
    });
    await refreshStudentData();
    toast(response.message);
  } catch (error) {
    button.disabled = false;
    toast(error.message, true);
  }
}

function pageMarkup() {
  if (state.page === "attendance") return attendancePage();
  if (state.page === "students") return state.rosterView === "classes" ? classroomsPage() : studentsPage();
  if (state.page === "reports") return reportsPage();
  if (state.page === "library") return libraryPage();
  if (state.page === "notices") return noticesPage();
  return dashboardPage();
}

function dailyCounts(date) {
  const records = state.data.attendance[date] || {};
  const statuses = Object.values(records);
  return {
    present: statuses.filter((status) => status === "present").length,
    late: statuses.filter((status) => status === "late").length,
    absent: statuses.filter((status) => status === "absent").length,
    marked: statuses.length,
  };
}

function percentage(earned, total) {
  return total ? Math.round((earned / total) * 100) : 0;
}

function dashboardPage() {
  const today = dailyCounts(localDateKey(new Date()));
  const headCount = state.data.students.length;
  const attended = today.present + today.late;
  const rate = percentage(attended, today.marked);
  const trend = [];
  for (let offset = 0; trend.length < 7; offset += 1) {
    const date = new Date();
    date.setDate(date.getDate() - offset);
    if (date.getDay() === 0 || date.getDay() === 6) continue;
    const key = localDateKey(date);
    const counts = dailyCounts(key);
    trend.unshift({ key, counts, rate: percentage(counts.present + counts.late, counts.marked) });
  }
  const maxValue = Math.max(100, ...trend.map((item) => item.rate));
  const chartBars = trend.map((item, index) => {
    const height = Math.max(3, (item.rate / maxValue) * 136);
    const x = 35 + index * 62;
    const y = 158 - height;
    return `<rect class="chart-bar ${index === 6 ? "today" : ""}" x="${x}" y="${y}" width="27" height="${height}"><title>${escapeHtml(dateLabel(item.key))}: ${item.rate}% checked in</title></rect><text class="chart-label" x="${x + 13.5}" y="181" text-anchor="middle">${escapeHtml(new Intl.DateTimeFormat("en", { weekday: "short" }).format(new Date(`${item.key}T12:00:00`)))}</text>`;
  }).join("");
  const classRows = state.data.classes.map((item) => {
    const students = classStudents(item.id);
    const records = state.data.attendance[localDateKey(new Date())] || {};
    const statuses = students.map((student) => records[student.id]).filter(Boolean);
    const present = statuses.filter((status) => status === "present" || status === "late").length;
    const rateForClass = percentage(present, statuses.length);
    return `<div class="class-row"><div class="class-initial">${escapeHtml(item.name[0] || "C")}</div><div><div class="class-row-name">${escapeHtml(item.grade)} · ${escapeHtml(item.name)}</div><div class="class-row-meta">${students.length} students on the roster</div><div class="progress-track"><div class="progress-fill" style="width:${rateForClass}%"></div></div></div><strong class="class-row-percent">${statuses.length ? `${rateForClass}%` : "—"}</strong></div>`;
  }).join("");
  const recent = state.data.students.slice(0, 5);
  const recentRows = recent.map((student) => `<tr><td><div class="student-cell"><span class="student-avatar">${escapeHtml(initials(student.name))}</span>${escapeHtml(student.name)}</div></td><td>${escapeHtml(className(student.classId))}</td><td>${statusPill(statusFor(student.id, localDateKey(new Date())))}</td></tr>`).join("");
  const noticePreview = (state.data.notices || []).slice(0, 2).map((notice) => `<article class="notice-preview"><span class="notice-type ${escapeHtml(notice.type)}">${noticeTypeLabel(notice.type)}</span><strong>${escapeHtml(notice.title)}</strong><span>${escapeHtml(dateLabel(notice.createdAt.slice(0, 10), { month: "short", day: "numeric" }))}</span></article>`).join("");
  return `
    <section class="campus-hero">
      <div class="campus-hero-copy"><p class="eyebrow">YOUR DAY, WELL CONNECTED</p><h1>Welcome to Campus One.</h1><p>Your campus, classes, and community—all in one place. Make today a good one.</p><div class="hero-actions"><button class="button" data-page="attendance">Take attendance <span aria-hidden="true">→</span></button><button class="hero-link" data-page="notices">Explore campus updates <span aria-hidden="true">↗</span></button></div></div>
      <div class="campus-scene" role="img" aria-label="Illustration of the Campus One college building"><div class="scene-sun"></div><div class="scene-cloud cloud-one"></div><div class="scene-cloud cloud-two"></div><div class="campus-tree tree-left"><i></i><i></i><b></b></div><div class="campus-building"><div class="building-roof"></div><div class="building-body"><div class="building-sign">CAMPUS ONE</div><div class="building-columns"><i></i><i></i><i></i><i></i><i></i></div><div class="building-entrance"></div><div class="building-windows"><i></i><i></i><i></i><i></i><i></i><i></i></div></div><div class="building-steps"></div></div><div class="campus-tree tree-right"><i></i><i></i><b></b></div><div class="campus-ground"></div></div>
    </section>
    <div class="page-heading campus-greeting"><div><p class="eyebrow">A FRESH LOOK AT TODAY</p><h2>Good ${greeting()}, faculty.</h2><p class="heading-sub">Here’s what’s happening across your campus.</p></div><button class="button secondary" data-page="library">Browse the library <span aria-hidden="true">↗</span></button></div>
    <section class="metric-grid" aria-label="Today's attendance summary">
      ${metricCard("Students", headCount, "Across your campus", "♧")}
      ${metricCard("Courses", state.data.classes.length, "Ready for a check-in", "▦")}
      ${metricCard("Here today", `${rate}%`, `${attended} of ${today.marked || headCount} marked present or late`, "✓")}
      ${metricCard("Away today", today.absent, today.marked ? `${today.late} arrived a little late` : "No attendance marked yet", "◷")}
    </section>
    <section class="dashboard-grid">
      <article class="panel"><div class="panel-heading"><div><h2>A week of showing up</h2><p class="section-sub">Attendance rate across your courses</p></div><span class="pill present">Last 7 days</span></div><div class="chart-wrap"><svg viewBox="0 0 475 190" role="img" aria-label="Attendance rates across the last seven days"><line class="chart-gridline" x1="25" y1="22" x2="465" y2="22"></line><line class="chart-gridline" x1="25" y1="67" x2="465" y2="67"></line><line class="chart-gridline" x1="25" y1="112" x2="465" y2="112"></line><line class="chart-gridline" x1="25" y1="158" x2="465" y2="158"></line><text class="chart-label" x="0" y="25">100%</text><text class="chart-label" x="8" y="70">66%</text><text class="chart-label" x="8" y="115">33%</text>${chartBars}</svg></div><div class="chart-legend"><span class="legend-item"><i class="legend-dot"></i>Checked in</span><span class="legend-item"><i class="legend-dot late"></i>Late</span><span class="legend-item"><i class="legend-dot absent"></i>Away</span></div></article>
      <article class="panel"><div class="panel-heading"><div><h2>Your courses</h2><p class="section-sub">A quick look at today</p></div><button class="icon-button" data-page="reports" aria-label="View course reports">↗</button></div><div class="class-list">${classRows || emptyState("No courses yet", "Add a course to get started.")}</div></article>
    </section>
    <section class="dashboard-grid dashboard-lower"><section class="table-panel"><div class="table-head"><div><h2>A few familiar faces</h2><p class="section-sub">Today's attendance check-in</p></div><button class="button secondary small" data-page="students">View student roster <span aria-hidden="true">→</span></button></div>${recentRows.length ? `<div class="table-wrap"><table><thead><tr><th>Student</th><th>Course</th><th>Today's status</th></tr></thead><tbody>${recentRows}</tbody></table></div>` : emptyState("Your roster is ready when you are", "Add students to see them here.")}</section><article class="panel latest-notices"><div class="panel-heading"><div><h2>On campus</h2><p class="section-sub">A note from your community</p></div><button class="icon-button" data-page="notices" aria-label="View all notices">↗</button></div><div class="notice-preview-list">${noticePreview || emptyState("No campus updates yet", "Check back soon.")}</div><button class="hero-link notice-view-all" data-page="notices">Visit the notice board <span aria-hidden="true">→</span></button></article></section>`;
}

function greeting() {
  const hour = new Date().getHours();
  return hour < 12 ? "morning" : hour < 17 ? "afternoon" : "evening";
}

function metricCard(label, value, note, icon) {
  return `<article class="metric-card"><div class="metric-top"><span>${label}</span><span class="metric-icon" aria-hidden="true">${icon}</span></div><div class="metric-value">${value}</div><div class="metric-foot">${note}</div></article>`;
}

function emptyState(title, message) {
  return `<div class="empty-state"><div class="empty-illustration" aria-hidden="true">✦</div><strong>${escapeHtml(title)}</strong>${escapeHtml(message)}</div>`;
}

function statusPill(status) {
  const normalized = ["present", "late", "absent"].includes(status) ? status : "unmarked";
  const label = { present: "Present", late: "Late", absent: "Absent", unmarked: "Not marked" }[normalized];
  return `<span class="pill ${normalized}">${label}</span>`;
}

function attendancePage() {
  if (!state.selectedClass && state.data.classes.length) state.selectedClass = state.data.classes[0].id;
  const students = classStudents(state.selectedClass).filter((student) => {
    const status = statusFor(student.id);
    return state.attendanceFilter === "all" || status === state.attendanceFilter;
  });
  const selectedClass = state.data.classes.find((item) => item.id === state.selectedClass);
  const counts = selectedClass ? classStudents(selectedClass.id).reduce((result, student) => {
    result[statusFor(student.id)] += 1;
    return result;
  }, { present: 0, late: 0, absent: 0, unmarked: 0 }) : { present: 0, late: 0, absent: 0, unmarked: 0 };
  const options = state.data.classes.map((item) => `<option value="${escapeHtml(item.id)}" ${item.id === state.selectedClass ? "selected" : ""}>${escapeHtml(item.grade)} · ${escapeHtml(item.name)}</option>`).join("");
  const rows = students.map((student) => `<tr><td><div class="student-cell"><span class="student-avatar">${escapeHtml(initials(student.name))}</span><span>${escapeHtml(student.name)}</span></div></td><td>${escapeHtml(student.rollNumber)}</td><td>${escapeHtml(className(student.classId))}</td><td><div class="status-actions">${["present", "late", "absent"].map((status) => `<button class="status-button ${statusFor(student.id) === status ? `selected ${status}` : ""}" data-status="${status}" data-student="${escapeHtml(student.id)}" aria-pressed="${statusFor(student.id) === status}">${status[0].toUpperCase()}${status.slice(1)}</button>`).join("")}</div></td></tr>`).join("");
  const tableContent = rows ? `<div class="table-wrap"><table><thead><tr><th>Student</th><th>Roll no.</th><th>Classroom</th><th>Mark as</th></tr></thead><tbody>${rows}</tbody></table></div>` : emptyState(selectedClass ? "No students match this view" : "No classrooms to take attendance", selectedClass ? "Try another filter or add a student to this classroom." : "Create a classroom roster to begin.");
  return `
    <div class="page-heading"><div><p class="eyebrow">One day at a time</p><h1>Take attendance</h1><p class="heading-sub">A quick check-in makes all the difference.</p></div><button class="button ${state.saving ? "soft" : ""}" data-action="save" ${state.saving ? "disabled" : ""}>${state.saving ? "Saving…" : "Save attendance"}</button></div>
    <section class="metric-grid" aria-label="Attendance counts">
      ${metricCard("Present", counts.present, "Here and ready to learn", "✓")}
      ${metricCard("Late", counts.late, "Arrived after the bell", "◷")}
      ${metricCard("Absent", counts.absent, "Not in class today", "—")}
      ${metricCard("Not marked", counts.unmarked, "Still needs a check-in", "○")}
    </section>
    <section class="table-panel"><div class="attendance-toolbar"><div class="attendance-date"><label class="eyebrow" for="attendance-date" style="margin:0">Date</label><input class="field" id="attendance-date" type="date" value="${escapeHtml(state.attendanceDate)}"><select id="attendance-class" class="select" aria-label="Choose classroom">${options}</select></div><div class="toolbar"><select id="attendance-filter" class="select filter-select" aria-label="Filter by status"><option value="all" ${state.attendanceFilter === "all" ? "selected" : ""}>Everyone</option><option value="unmarked" ${state.attendanceFilter === "unmarked" ? "selected" : ""}>Not marked</option><option value="present" ${state.attendanceFilter === "present" ? "selected" : ""}>Present</option><option value="late" ${state.attendanceFilter === "late" ? "selected" : ""}>Late</option><option value="absent" ${state.attendanceFilter === "absent" ? "selected" : ""}>Absent</option></select><button class="button secondary small" data-action="mark-all">Mark all present</button></div></div>${tableContent}<div class="pagination-note">${selectedClass ? `${classStudents(selectedClass.id).length} students · ${counts.present + counts.late + counts.absent} marked` : "Add a class and students to begin"} <span style="float:right">Changes save securely to this device’s server</span></div></section>`;
}

function studentsPage() {
  const filtered = state.data.students.filter((student) => {
    const matchesText = `${student.name} ${student.rollNumber} ${studentLoginEmail(student)} ${className(student.classId)}`.toLowerCase().includes(state.studentSearch.toLowerCase());
    const matchesClass = state.studentClassFilter === "all" || student.classId === state.studentClassFilter;
    return matchesText && matchesClass;
  });
  const rows = filtered.map((student) => `<tr><td><div class="student-cell"><span class="student-avatar">${escapeHtml(initials(student.name))}</span><span class="student-identity"><strong>${escapeHtml(student.name)}</strong><small>${escapeHtml(studentLoginEmail(student))}</small></span></div></td><td>${escapeHtml(student.rollNumber)}</td><td>${escapeHtml(className(student.classId))}</td><td>${statusPill(statusFor(student.id, localDateKey(new Date())))}</td></tr>`).join("");
  const classOptions = state.data.classes.map((item) => `<option value="${escapeHtml(item.id)}" ${state.studentClassFilter === item.id ? "selected" : ""}>${escapeHtml(item.grade)} · ${escapeHtml(item.name)}</option>`).join("");
  return `
    <div class="page-heading"><div><p class="eyebrow">The people who make it a classroom</p><h1>Student roster</h1><p class="heading-sub">Find a student, check their classroom, or add someone new.</p></div><button class="button" data-action="add-student">＋ <span>Add student</span></button></div>
    ${rosterTabs()}
    <section class="metric-grid" aria-label="Roster summary">${metricCard("Students", state.data.students.length, "In your roster", "♧")}${metricCard("Classrooms", state.data.classes.length, "Across your school day", "▦")}${metricCard("Here today", dailyCounts(localDateKey(new Date())).present + dailyCounts(localDateKey(new Date())).late, "Present or arrived late", "✓")}${metricCard("Roster status", state.data.students.length ? "Looking good" : "Getting started", "Keep your class lists up to date", "✦")}</section>
    <section class="table-panel"><div class="table-head"><div><h2>All students <span style="color:#9aa29d;font:500 11px 'DM Sans',sans-serif">(${filtered.length})</span></h2><p class="section-sub">Your roster, all in one place</p></div><div class="table-head-actions"><input class="field search-field" id="student-search" type="search" placeholder="Search students…" value="${escapeHtml(state.studentSearch)}" aria-label="Search students"><select class="select filter-select" id="student-class-filter" aria-label="Filter by classroom"><option value="all" ${state.studentClassFilter === "all" ? "selected" : ""}>All classrooms</option>${classOptions}</select><button class="button secondary small" data-action="export-students">↓ CSV</button></div></div>${rows ? `<div class="table-wrap"><table><thead><tr><th>Student</th><th>Roll no.</th><th>Classroom</th><th>Today's status</th></tr></thead><tbody>${rows}</tbody></table></div>` : emptyState(state.data.students.length ? "No students found" : "Your roster starts here", state.data.students.length ? "Try a different name or classroom filter." : "Add your first student to begin.")}<div class="pagination-note">Showing ${filtered.length} of ${state.data.students.length} students</div></section>`;
}

function rosterTabs() {
  return `<div class="roster-tabs" role="tablist" aria-label="Roster type"><button class="roster-tab ${state.rosterView === "students" ? "active" : ""}" role="tab" aria-selected="${state.rosterView === "students"}" data-roster-view="students">Students <span>${state.data.students.length}</span></button><button class="roster-tab ${state.rosterView === "classes" ? "active" : ""}" role="tab" aria-selected="${state.rosterView === "classes"}" data-roster-view="classes">Classrooms <span>${state.data.classes.length}</span></button></div>`;
}

function classroomsPage() {
  const grades = [...new Set(state.data.classes.map((item) => item.grade))].sort();
  const classes = state.data.classes.filter((item) => {
    const matchesText = `${item.name} ${item.grade}`.toLowerCase().includes(state.classSearch.toLowerCase());
    return matchesText && (state.classGradeFilter === "all" || item.grade === state.classGradeFilter);
  });
  const rows = classes.map((item) => {
    const students = classStudents(item.id);
    const records = state.data.attendance[localDateKey(new Date())] || {};
    const marked = students.map((student) => records[student.id]).filter(Boolean);
    const attended = marked.filter((status) => status === "present" || status === "late").length;
    return `<tr><td><div class="student-cell"><span class="class-initial">${escapeHtml(item.name[0] || "C")}</span>${escapeHtml(item.name)}</div></td><td>${escapeHtml(item.grade)}</td><td>${students.length}</td><td>${marked.length ? `${percentage(attended, marked.length)}%` : "—"}</td></tr>`;
  }).join("");
  return `
    <div class="page-heading"><div><p class="eyebrow">Every class, in its place</p><h1>Classrooms</h1><p class="heading-sub">Keep your class groups tidy and easy to find.</p></div><button class="button" data-action="add-class">＋ <span>Add classroom</span></button></div>
    ${rosterTabs()}
    <section class="metric-grid" aria-label="Classroom summary">${metricCard("Classrooms", state.data.classes.length, "In your workspace", "▦")}${metricCard("Grade levels", grades.length, "Across your classes", "⌂")}${metricCard("Students", state.data.students.length, "On the combined roster", "♧")}${metricCard("Checked in", dailyCounts(localDateKey(new Date())).present + dailyCounts(localDateKey(new Date())).late, "Present or arrived late", "✓")}</section>
    <section class="table-panel"><div class="table-head"><div><h2>All classrooms <span style="color:#9aa29d;font:500 11px 'DM Sans',sans-serif">(${classes.length})</span></h2><p class="section-sub">Search by classroom name or filter by grade.</p></div><div class="table-head-actions"><input class="field search-field" id="class-search" type="search" placeholder="Search classrooms…" value="${escapeHtml(state.classSearch)}" aria-label="Search classrooms"><select class="select filter-select" id="class-grade-filter" aria-label="Filter by grade"><option value="all" ${state.classGradeFilter === "all" ? "selected" : ""}>All grades</option>${grades.map((grade) => `<option value="${escapeHtml(grade)}" ${state.classGradeFilter === grade ? "selected" : ""}>${escapeHtml(grade)}</option>`).join("")}</select></div></div>${rows ? `<div class="table-wrap"><table><thead><tr><th>Classroom</th><th>Grade</th><th>Students</th><th>Today's attendance</th></tr></thead><tbody>${rows}</tbody></table></div>` : emptyState(state.data.classes.length ? "No classrooms found" : "Your classrooms start here", state.data.classes.length ? "Try another search or grade filter." : "Add a classroom to organize your students.")}<div class="pagination-note">Showing ${classes.length} of ${state.data.classes.length} classrooms</div></section>`;
}

function reportRange() {
  const end = new Date();
  const start = new Date();
  start.setDate(start.getDate() - Number(state.reportPeriod) + 1);
  return { start: localDateKey(start), end: localDateKey(end) };
}

function reportRows() {
  const { start, end } = reportRange();
  const students = state.data.students.filter((student) => state.reportClass === "all" || student.classId === state.reportClass);
  return students.map((student) => {
    let present = 0;
    let late = 0;
    let absent = 0;
    let marked = 0;
    Object.entries(state.data.attendance).forEach(([date, records]) => {
      if (date < start || date > end || (state.reportClass !== "all" && student.classId !== state.reportClass)) return;
      const status = records[student.id];
      if (status && ["present", "late", "absent"].includes(status)) {
        marked += 1;
        if (status === "present") present += 1;
        if (status === "late") late += 1;
        if (status === "absent") absent += 1;
      }
    });
    const rate = percentage(present + late, marked);
    return { student, present, late, absent, marked, rate };
  });
}

function reportsPage() {
  const rows = reportRows();
  const totalMarked = rows.reduce((sum, row) => sum + row.marked, 0);
  const totalAttended = rows.reduce((sum, row) => sum + row.present + row.late, 0);
  const totalAbsent = rows.reduce((sum, row) => sum + row.absent, 0);
  const average = percentage(totalAttended, totalMarked);
  const { start, end } = reportRange();
  const classOptions = state.data.classes.map((item) => `<option value="${escapeHtml(item.id)}" ${state.reportClass === item.id ? "selected" : ""}>${escapeHtml(item.grade)} · ${escapeHtml(item.name)}</option>`).join("");
  const tableRows = rows.map((row) => `<tr><td><div class="student-cell"><span class="student-avatar">${escapeHtml(initials(row.student.name))}</span>${escapeHtml(row.student.name)}</div></td><td>${escapeHtml(className(row.student.classId))}</td><td>${row.marked}</td><td>${row.present}</td><td>${row.late}</td><td>${row.absent}</td><td><span class="percentage" style="color:${row.rate >= 90 ? "#548064" : row.rate >= 75 ? "#ad883d" : "#bc6d65"}">${row.marked ? `${row.rate}%` : "—"}</span></td></tr>`).join("");
  return `
    <div class="page-heading"><div><p class="eyebrow">Patterns, not just numbers</p><h1>Attendance reports</h1><p class="heading-sub">Understand the rhythm of attendance across your classrooms.</p></div><button class="button secondary" data-action="export-report">↓ <span>Export CSV</span></button></div>
    <div class="toolbar" style="margin-bottom:17px"><select class="select filter-select" id="report-period" aria-label="Choose report period"><option value="7" ${state.reportPeriod === 7 ? "selected" : ""}>Last 7 days</option><option value="30" ${state.reportPeriod === 30 ? "selected" : ""}>Last 30 days</option><option value="90" ${state.reportPeriod === 90 ? "selected" : ""}>This term · 90 days</option></select><select class="select filter-select" id="report-class" aria-label="Filter report by classroom"><option value="all" ${state.reportClass === "all" ? "selected" : ""}>All classrooms</option>${classOptions}</select><span class="today-label">${dateLabel(start, { month: "short", day: "numeric", year: "numeric" })} — ${dateLabel(end, { month: "short", day: "numeric", year: "numeric" })}</span></div>
    <section class="report-summary" aria-label="Report totals"><article class="report-card"><div class="report-card-label">Overall attendance</div><div class="report-card-value">${totalMarked ? `${average}%` : "—"}</div><div class="report-card-note">Present or late across marked sessions</div></article><article class="report-card"><div class="report-card-label">Marked check-ins</div><div class="report-card-value">${totalMarked}</div><div class="report-card-note">Student attendance records in this period</div></article><article class="report-card"><div class="report-card-label">Absences</div><div class="report-card-value">${totalAbsent}</div><div class="report-card-note">Across ${rows.length} students</div></article></section>
    <section class="table-panel"><div class="table-head"><div><h2>Student attendance</h2><p class="section-sub">Present and late count as attended. Unmarked sessions are excluded.</p></div><span class="pill present">${state.reportClass === "all" ? "All classrooms" : escapeHtml(className(state.reportClass))}</span></div>${tableRows.length ? `<div class="table-wrap"><table><thead><tr><th>Student</th><th>Classroom</th><th>Sessions</th><th>Present</th><th>Late</th><th>Absent</th><th>Attendance</th></tr></thead><tbody>${tableRows}</tbody></table></div>` : emptyState("No attendance data for this period", "Change the date range or record attendance to see a report.")}<div class="pagination-note">Attendance percentage = (present + late) ÷ marked sessions. Students with no marked sessions show —.</div></section>`;
}

function noticeTypeLabel(type) {
  return { announcement: "Announcement", homework: "Homework", event: "Campus event", update: "Campus update" }[type] || "Campus note";
}

function noticeTime(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Recently posted";
  const elapsed = Math.max(0, Date.now() - date.getTime());
  if (elapsed < 60 * 60 * 1000) return "Just posted";
  if (elapsed < 24 * 60 * 60 * 1000) return `${Math.floor(elapsed / (60 * 60 * 1000))}h ago`;
  if (elapsed < 48 * 60 * 60 * 1000) return "Yesterday";
  return new Intl.DateTimeFormat("en", { month: "short", day: "numeric" }).format(date);
}

function noticesPage() {
  const notices = (state.data.notices || []).filter((notice) => state.noticeType === "all" || notice.type === state.noticeType);
  const noticeCards = notices.map((notice) => {
    const course = notice.classId ? state.data.classes.find((item) => item.id === notice.classId) : null;
    return `<article class="notice-card"><div class="notice-card-top"><span class="notice-type ${escapeHtml(notice.type)}">${noticeTypeLabel(notice.type)}</span><time datetime="${escapeHtml(notice.createdAt)}">${escapeHtml(noticeTime(notice.createdAt))}</time></div><h2>${escapeHtml(notice.title)}</h2><p>${escapeHtml(notice.body)}</p><div class="notice-card-footer"><div class="notice-author"><span class="student-avatar">${escapeHtml(initials(notice.author))}</span><span>${escapeHtml(notice.author)}</span></div><span class="notice-audience">${course ? `${escapeHtml(course.grade)} · ${escapeHtml(course.name)}` : "All campus"}</span></div></article>`;
  }).join("");
  return `
    <div class="page-heading"><div><p class="eyebrow">Good things travel by word of mouth</p><h1>Campus notice board</h1><p class="heading-sub">Updates, events, and notes for the people who make this place.</p></div><button class="button" data-action="add-notice">＋ <span>Post an update</span></button></div>
    <div class="notice-toolbar"><div><span class="notice-online-dot"></span>Community board <span class="notice-count">${(state.data.notices || []).length} posts</span></div><select class="select filter-select" id="notice-type-filter" aria-label="Filter notices"><option value="all" ${state.noticeType === "all" ? "selected" : ""}>Everything</option><option value="announcement" ${state.noticeType === "announcement" ? "selected" : ""}>Announcements</option><option value="homework" ${state.noticeType === "homework" ? "selected" : ""}>Homework</option><option value="event" ${state.noticeType === "event" ? "selected" : ""}>Events</option><option value="update" ${state.noticeType === "update" ? "selected" : ""}>Campus updates</option></select></div>
    <section class="notice-grid" aria-label="Campus notices">${noticeCards || emptyState("Nothing on this board yet", "Try another filter or post the first update for your community.")}</section>`;
}

function libraryPage() {
  const books = state.data.library || [];
  const categories = [...new Set(books.map((book) => book.category))].sort();
  const filtered = books.filter((book) => {
    const matchesText = `${book.title} ${book.author} ${book.category} ${book.description}`.toLowerCase().includes(state.librarySearch.toLowerCase());
    return matchesText && (state.libraryCategory === "all" || book.category === state.libraryCategory);
  });
  const cards = filtered.map((book) => `<article class="library-card"><div class="library-art ${escapeHtml(book.category.toLowerCase().replace(/[^a-z0-9]+/g, "-"))}"><span class="book-mark">C1</span><span class="book-category">${escapeHtml(book.category)}</span><span class="book-lines"></span></div><div class="library-card-content"><span class="library-format">${escapeHtml(book.format)}</span><h2>${escapeHtml(book.title)}</h2><div class="library-author">By ${escapeHtml(book.author)}</div><p>${escapeHtml(book.description)}</p><a class="button secondary small resource-link" href="${escapeHtml(book.url)}" target="_blank" rel="noopener noreferrer">Open resource <span aria-hidden="true">↗</span></a></div></article>`).join("");
  return `
    <div class="page-heading"><div><p class="eyebrow">A little curiosity goes a long way</p><h1>Digital library</h1><p class="heading-sub">Open resources and good reads, gathered for your next big idea.</p></div></div>
    <section class="library-welcome"><div class="library-welcome-icon">✳</div><div><strong>Good learning should be easy to reach.</strong><p>Browse open textbooks, trusted learning guides, and thoughtful study resources—free to explore.</p></div><span class="library-resource-count">${books.length} hand-picked resources</span></section>
    <div class="library-toolbar"><label class="sr-only" for="library-search">Search the library</label><input class="field search-field" id="library-search" type="search" placeholder="Search books, subjects, authors…" value="${escapeHtml(state.librarySearch)}"><select id="library-category" class="select filter-select" aria-label="Filter by subject"><option value="all" ${state.libraryCategory === "all" ? "selected" : ""}>All subjects</option>${categories.map((category) => `<option value="${escapeHtml(category)}" ${state.libraryCategory === category ? "selected" : ""}>${escapeHtml(category)}</option>`).join("")}</select><span class="library-result-count">${filtered.length} resources</span></div>
    <section class="library-grid" aria-label="Library resources">${cards || emptyState("No resources found", "Try another search or choose a different subject.")}</section>`;
}

function bindPageEvents() {
  app.querySelectorAll("[data-page]").forEach((button) => button.addEventListener("click", () => {
    state.page = button.dataset.page;
    render();
  }));
  app.querySelector('[data-action="logout"]')?.addEventListener("click", logout);
  app.querySelector('[data-action="save"]')?.addEventListener("click", saveAttendance);
  app.querySelector('[data-action="mark-all"]')?.addEventListener("click", markAllPresent);
  app.querySelector('[data-action="add-student"]')?.addEventListener("click", showAddStudent);
  app.querySelector('[data-action="add-class"]')?.addEventListener("click", showAddClass);
  app.querySelector('[data-action="add-notice"]')?.addEventListener("click", showAddNotice);
  app.querySelector('[data-action="export-students"]')?.addEventListener("click", exportStudents);
  app.querySelector('[data-action="export-report"]')?.addEventListener("click", exportReport);

  app.querySelector("#attendance-class")?.addEventListener("change", (event) => {
    state.selectedClass = event.target.value;
    render();
  });
  app.querySelector("#attendance-date")?.addEventListener("change", (event) => {
    state.attendanceDate = event.target.value || localDateKey(new Date());
    render();
  });
  app.querySelector("#attendance-filter")?.addEventListener("change", (event) => {
    state.attendanceFilter = event.target.value;
    render();
  });
  app.querySelectorAll("[data-status]").forEach((button) => button.addEventListener("click", () => {
    setStatus(button.dataset.student, button.dataset.status);
  }));
  app.querySelectorAll("[data-roster-view]").forEach((button) => button.addEventListener("click", () => {
    state.rosterView = button.dataset.rosterView;
    render();
  }));
  app.querySelector("#student-search")?.addEventListener("input", (event) => {
    state.studentSearch = event.target.value;
    const cursor = event.target.selectionStart;
    render();
    const search = app.querySelector("#student-search");
    search.focus();
    search.setSelectionRange(cursor, cursor);
  });
  app.querySelector("#student-class-filter")?.addEventListener("change", (event) => {
    state.studentClassFilter = event.target.value;
    render();
  });
  app.querySelector("#class-search")?.addEventListener("input", (event) => {
    state.classSearch = event.target.value;
    const cursor = event.target.selectionStart;
    render();
    const search = app.querySelector("#class-search");
    search.focus();
    search.setSelectionRange(cursor, cursor);
  });
  app.querySelector("#class-grade-filter")?.addEventListener("change", (event) => {
    state.classGradeFilter = event.target.value;
    render();
  });
  app.querySelector("#report-class")?.addEventListener("change", (event) => {
    state.reportClass = event.target.value;
    render();
  });
  app.querySelector("#report-period")?.addEventListener("change", (event) => {
    state.reportPeriod = Number(event.target.value);
    render();
  });
  app.querySelector("#notice-type-filter")?.addEventListener("change", (event) => {
    state.noticeType = event.target.value;
    render();
  });
  app.querySelector("#library-category")?.addEventListener("change", (event) => {
    state.libraryCategory = event.target.value;
    render();
  });
  app.querySelector("#library-search")?.addEventListener("input", (event) => {
    state.librarySearch = event.target.value;
    const cursor = event.target.selectionStart;
    render();
    const search = app.querySelector("#library-search");
    search.focus();
    search.setSelectionRange(cursor, cursor);
  });
}

function setStatus(studentId, status) {
  if (!state.data.attendance[state.attendanceDate]) state.data.attendance[state.attendanceDate] = {};
  state.data.attendance[state.attendanceDate][studentId] = status;
  render();
}

function markAllPresent() {
  if (!state.selectedClass) {
    toast("Add a classroom before marking attendance.", true);
    return;
  }
  if (!state.data.attendance[state.attendanceDate]) state.data.attendance[state.attendanceDate] = {};
  classStudents(state.selectedClass).forEach((student) => {
    state.data.attendance[state.attendanceDate][student.id] = "present";
  });
  render();
  toast("Everyone in this classroom is marked present.");
}

async function saveAttendance() {
  const button = app.querySelector('[data-action="save"]');
  if (button) {
    button.disabled = true;
    button.textContent = "Saving…";
  }
  state.saving = true;
  try {
    await api("/api/data", { method: "PUT", body: JSON.stringify(state.data) });
    state.saving = false;
    render();
    toast("Attendance saved. Your records are up to date.");
  } catch (error) {
    state.saving = false;
    render();
    toast(error.message, true);
  }
}

async function logout() {
  try {
    const wasStudent = state.user?.role === "student";
    await api(wasStudent ? "/api/student/logout" : "/api/logout", { method: "POST", body: "{}" });
    state.user = null;
    state.data = null;
    state.studentData = null;
    state.page = wasStudent ? "student-home" : "dashboard";
    state.loginRole = wasStudent ? "student" : "teacher";
    showLogin();
  } catch (error) {
    toast(error.message, true);
  }
}

function showStudentPasswordDialog() {
  const overlay = document.querySelector("#overlay-root");
  overlay.innerHTML = `<div class="modal-backdrop" role="presentation"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="student-password-title"><div class="modal-heading"><div><p class="eyebrow">Keep your account yours</p><h2 id="student-password-title">Update password</h2></div><button class="modal-close" data-action="close-modal" aria-label="Close dialog">×</button></div><form id="student-password-form"><div class="form-group"><label for="current-student-password">Current password</label><input id="current-student-password" name="currentPassword" type="password" autocomplete="current-password" required></div><div class="form-group"><label for="new-student-password">New password</label><input id="new-student-password" name="newPassword" type="password" minlength="12" autocomplete="new-password" required><small>Use at least 12 characters.</small></div><p class="login-error" id="student-password-error" role="alert"></p><div class="modal-actions"><button type="button" class="button secondary" data-action="close-modal">Cancel</button><button type="submit" class="button">Save password</button></div></form></section></div>`;
  overlay.querySelectorAll('[data-action="close-modal"]').forEach((button) => button.addEventListener("click", () => { overlay.innerHTML = ""; }));
  overlay.querySelector(".modal-backdrop").addEventListener("click", (event) => {
    if (event.target === event.currentTarget) overlay.innerHTML = "";
  });
  overlay.querySelector("#student-password-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const submit = event.currentTarget.querySelector('button[type="submit"]');
    submit.disabled = true;
    try {
      await api("/api/student/password", {
        method: "POST",
        body: JSON.stringify({ currentPassword: form.get("currentPassword"), newPassword: form.get("newPassword") }),
      });
      overlay.innerHTML = "";
      toast("Your password has been updated.");
    } catch (error) {
      overlay.querySelector("#student-password-error").textContent = error.message;
      submit.disabled = false;
    }
  });
  overlay.querySelector("#current-student-password").focus();
}

function showAddStudent() {
  const overlay = document.querySelector("#overlay-root");
  if (!state.data.classes.length) {
    toast("There are no classrooms yet. Ask your administrator to add one.", true);
    return;
  }
  overlay.innerHTML = `<div class="modal-backdrop" role="presentation"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-heading"><div><p class="eyebrow">Grow your classroom</p><h2 id="modal-title">Add a student</h2></div><button class="modal-close" data-action="close-modal" aria-label="Close dialog">×</button></div><form id="add-student-form"><div class="form-group"><label for="new-student-name">Student name</label><input id="new-student-name" name="name" maxlength="80" placeholder="e.g. Jordan Rivera" required></div><div class="form-group"><label for="new-student-class">Classroom</label><select id="new-student-class" name="classId" required>${state.data.classes.map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.grade)} · ${escapeHtml(item.name)}</option>`).join("")}</select></div><div class="form-group"><label for="new-student-roll">Roll number</label><input id="new-student-roll" name="rollNumber" maxlength="20" placeholder="e.g. 21" required></div><p class="login-error" id="add-student-error" role="alert"></p><div class="modal-actions"><button type="button" class="button secondary" data-action="close-modal">Cancel</button><button type="submit" class="button">Add student</button></div></form></section></div>`;
  overlay.querySelectorAll('[data-action="close-modal"]').forEach((button) => button.addEventListener("click", () => { overlay.innerHTML = ""; }));
  overlay.querySelector(".modal-backdrop").addEventListener("click", (event) => {
    if (event.target === event.currentTarget) overlay.innerHTML = "";
  });
  overlay.querySelector("#add-student-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const name = String(form.get("name")).trim();
    const rollNumber = String(form.get("rollNumber")).trim();
    const classId = String(form.get("classId"));
    if (!name || !rollNumber || !state.data.classes.some((item) => item.id === classId)) return;
    if (state.data.students.some((student) => student.classId === classId && student.rollNumber.toLowerCase() === rollNumber.toLowerCase())) {
      overlay.querySelector("#add-student-error").textContent = "That roll number is already used in this classroom.";
      return;
    }
    const student = { id: crypto.randomUUID(), name, classId, rollNumber };
    state.data.students.push(student);
    try {
      await api("/api/data", { method: "PUT", body: JSON.stringify(state.data) });
      state.studentAccounts = (await api("/api/student/accounts")).accounts;
      state.studentClassFilter = classId;
      state.studentSearch = "";
      overlay.innerHTML = "";
      render();
      toast(`${name} added. Student login: ${studentLoginEmail(student)}`);
    } catch (error) {
      state.data.students = state.data.students.filter((item) => item.id !== student.id);
      overlay.querySelector("#add-student-error").textContent = error.message;
    }
  });
  overlay.querySelector("#new-student-name").focus();
}

function showAddClass() {
  const overlay = document.querySelector("#overlay-root");
  overlay.innerHTML = `<div class="modal-backdrop" role="presentation"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-heading"><div><p class="eyebrow">Make room for a new group</p><h2 id="modal-title">Add a classroom</h2></div><button class="modal-close" data-action="close-modal" aria-label="Close dialog">×</button></div><form id="add-class-form"><div class="form-group"><label for="new-class-name">Classroom name</label><input id="new-class-name" name="name" maxlength="60" placeholder="e.g. Maple" required></div><div class="form-group"><label for="new-class-grade">Grade or level</label><input id="new-class-grade" name="grade" maxlength="40" placeholder="e.g. Grade 5" required></div><p class="login-error" id="add-class-error" role="alert"></p><div class="modal-actions"><button type="button" class="button secondary" data-action="close-modal">Cancel</button><button type="submit" class="button">Add classroom</button></div></form></section></div>`;
  overlay.querySelectorAll('[data-action="close-modal"]').forEach((button) => button.addEventListener("click", () => { overlay.innerHTML = ""; }));
  overlay.querySelector(".modal-backdrop").addEventListener("click", (event) => {
    if (event.target === event.currentTarget) overlay.innerHTML = "";
  });
  overlay.querySelector("#add-class-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const name = String(form.get("name")).trim();
    const grade = String(form.get("grade")).trim();
    if (!name || !grade) return;
    if (state.data.classes.some((item) => item.name.toLowerCase() === name.toLowerCase() && item.grade.toLowerCase() === grade.toLowerCase())) {
      overlay.querySelector("#add-class-error").textContent = "That classroom already exists for this grade.";
      return;
    }
    const classroom = { id: crypto.randomUUID(), name, grade };
    state.data.classes.push(classroom);
    try {
      await api("/api/data", { method: "PUT", body: JSON.stringify(state.data) });
      overlay.innerHTML = "";
      render();
      toast(`${grade} · ${name} was added.`);
    } catch (error) {
      state.data.classes = state.data.classes.filter((item) => item.id !== classroom.id);
      overlay.querySelector("#add-class-error").textContent = error.message;
    }
  });
  overlay.querySelector("#new-class-name").focus();
}

function showAddNotice() {
  const overlay = document.querySelector("#overlay-root");
  overlay.innerHTML = `<div class="modal-backdrop" role="presentation"><section class="modal notice-modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-heading"><div><p class="eyebrow">Share a word with your community</p><h2 id="modal-title">Post to the notice board</h2></div><button class="modal-close" data-action="close-modal" aria-label="Close dialog">×</button></div><form id="add-notice-form"><div class="form-group"><label for="new-notice-type">Post type</label><select id="new-notice-type" name="type"><option value="announcement">Announcement</option><option value="homework">Homework</option><option value="event">Campus event</option><option value="update">Campus update</option></select></div><div class="form-group"><label for="new-notice-title">Headline</label><input id="new-notice-title" name="title" maxlength="120" placeholder="What should everyone know?" required></div><div class="form-group"><label for="new-notice-body">Message</label><textarea id="new-notice-body" name="body" maxlength="2000" rows="5" placeholder="Add the details your community needs…" required></textarea></div><div class="form-group"><label for="new-notice-class">Share with</label><select id="new-notice-class" name="classId"><option value="all">Everyone on campus</option>${state.data.classes.map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.grade)} · ${escapeHtml(item.name)}</option>`).join("")}</select></div><p class="login-error" id="add-notice-error" role="alert"></p><div class="modal-actions"><button type="button" class="button secondary" data-action="close-modal">Cancel</button><button type="submit" class="button">Publish update</button></div></form></section></div>`;
  overlay.querySelectorAll('[data-action="close-modal"]').forEach((button) => button.addEventListener("click", () => { overlay.innerHTML = ""; }));
  overlay.querySelector(".modal-backdrop").addEventListener("click", (event) => {
    if (event.target === event.currentTarget) overlay.innerHTML = "";
  });
  overlay.querySelector("#add-notice-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const submit = event.currentTarget.querySelector('button[type="submit"]');
    submit.disabled = true;
    submit.textContent = "Publishing…";
    try {
      const result = await api("/api/notices", {
        method: "POST",
        body: JSON.stringify({
          type: form.get("type"),
          title: form.get("title"),
          body: form.get("body"),
          classId: form.get("classId"),
        }),
      });
      state.data.notices.unshift(result.notice);
      state.noticeType = "all";
      overlay.innerHTML = "";
      render();
      toast("Your update is live on the campus notice board.");
    } catch (error) {
      overlay.querySelector("#add-notice-error").textContent = error.message;
      submit.disabled = false;
      submit.textContent = "Publish update";
    }
  });
  overlay.querySelector("#new-notice-title").focus();
}

function csvCell(value) {
  const text = String(value ?? "");
  const safeText = /^[=+\-@\t\r]/.test(text) ? `'${text}` : text;
  return `"${safeText.replace(/"/g, '""')}"`;
}

function downloadCsv(filename, rows) {
  const csv = rows.map((row) => row.map(csvCell).join(",")).join("\r\n");
  const url = URL.createObjectURL(new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  toast("Your CSV export is ready.");
}

function exportStudents() {
  const students = state.data.students.filter((student) => {
    const searchMatch = `${student.name} ${student.rollNumber} ${studentLoginEmail(student)} ${className(student.classId)}`.toLowerCase().includes(state.studentSearch.toLowerCase());
    return searchMatch && (state.studentClassFilter === "all" || student.classId === state.studentClassFilter);
  });
  downloadCsv("classroom-students.csv", [
    ["Student name", "Roll number", "Classroom", "Grade"],
    ...students.map((student) => [student.name, student.rollNumber, state.data.classes.find((item) => item.id === student.classId)?.name || "", state.data.classes.find((item) => item.id === student.classId)?.grade || ""]),
  ]);
}

function exportReport() {
  const { start, end } = reportRange();
  const rows = [["Date", "Student name", "Roll number", "Classroom", "Status"]];
  Object.entries(state.data.attendance).sort(([a], [b]) => a.localeCompare(b)).forEach(([date, records]) => {
    if (date < start || date > end) return;
    state.data.students.forEach((student) => {
      if (state.reportClass !== "all" && student.classId !== state.reportClass) return;
      const status = records[student.id];
      if (!status) return;
      rows.push([date, student.name, student.rollNumber, className(student.classId), status]);
    });
  });
  downloadCsv(`attendance-report-${start}-to-${end}.csv`, rows);
}

let toastTimer;
function toast(message, isError = false) {
  document.querySelector(".toast")?.remove();
  const element = document.createElement("div");
  element.className = `toast${isError ? " error" : ""}`;
  element.setAttribute("role", isError ? "alert" : "status");
  element.textContent = message;
  document.body.append(element);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => element.remove(), 3400);
}

start();
