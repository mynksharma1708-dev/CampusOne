# Campus One

Campus One is a responsive faculty and student portal with a 3D-inspired campus home page, attendance marking and reports, searchable student/course management, a digital library and book loans, and a notice board for announcements, homework, events, and updates. Students can also review fee balances and submit clearly labeled payment simulations.

Built with Node.js and browser-native HTML, CSS, and JavaScript. No package install, external runtime service, or build step is required.

## Project layout

- `frontend/` contains the browser app (`index.html`, `styles.css`, and `app.js`).
- `backend/server.js` serves the UI and authenticated API.
- `database/campus.json` is the persistent, editable portal database, created on first launch and excluded from version control.
- `database/student-credentials.json` is generated separately for salted student password hashes and excluded from version control.
- `database/dataset/demo-seed.json` is the read-only sample dataset used when no database exists.
- `test/` contains the backend integration tests.

## Run locally

1. Install Node.js 20 or newer.
2. From this folder, double-click `start.bat` or run `npm start`.
3. Visit [http://127.0.0.1:3000](http://127.0.0.1:3000).
4. Sign in with **teacher@school.com** / **Attend2026!**.

The demo starts with sample students, courses, attendance, six campus notices, and six curated library resources. Changes are saved to `database/campus.json`; a missing database is initialized from `database/dataset/demo-seed.json`. Existing Classroom portal data was moved into the new database location and migrated to the Campus One format; student IDs and attendance records are retained.

## Student accounts and book loans

Choose **Student** on the sign-in screen. Demo student: **ava.thompson.01@students.campusone.edu** / **Student2026!**. The server also prints a valid student demo email and starter password at startup; if that account’s starter password has been changed, it prints another account still using the configured starter password. Other seeded student emails follow `firstname.lastname.rollnumber@students.campusone.edu` and use the same demo starter password. Students can review their own attendance history, see campus-wide and class-specific notices and events, view fee balances, submit payment simulations, issue available library books for 14 days (up to three at a time), return books, and change their password from their portal.

The fees page creates demo INR charges and stores each submission as a clearly labeled simulation. **It does not connect to a payment processor, collect payment credentials, move money, or reduce the balance.**

Student passwords are stored as individual salted scrypt hashes in `database/student-credentials.json`, separate from the teacher's campus data. The demo starter password is shared by seeded accounts for convenience; students should change it after signing in. To set a different initial password for accounts provisioned on the next startup, set `STUDENT_PASSWORD` before first launch. Changing this variable does not reset existing student passwords.

## Set a different teacher login

Set environment variables before starting the server:

```powershell
$env:TEACHER_EMAIL = "faculty@yourcollege.edu"
$env:TEACHER_PASSWORD = "choose-a-long-unique-password"
$env:STUDENT_PASSWORD = "choose-a-different-long-student-password"
npm start
```

The password is salted and hashed with scrypt in memory; it is not saved to disk. Login attempts are rate-limited. The session uses an HttpOnly, SameSite=Strict cookie. Set `NODE_ENV=production` when serving behind HTTPS to enable the Secure cookie flag. `HOST` defaults to `127.0.0.1`; set `HOST=0.0.0.0` only when intentionally making it reachable on your network. `PORT` defaults to `3000`.

## Tests

Run `npm test` for dependency-free Node.js integration tests covering access control, login, notice validation and publishing, fee simulation privacy and persistence, and persistence across a server restart. Tests use isolated temporary data files and an ephemeral port.

## Scope and privacy notes

This is a single-faculty starter portal with student accounts, not a full multi-tenant student information system. Fee amounts are sample data and payment submissions are simulations only; real payment processing, settlement, receipts, and account reconciliation are not implemented. It also does not include account self-registration, account recovery, or centralized enrollment integrations. Student records are JSON-backed, not SQL or encrypted at rest. Digital learning resources link to external sites. For real student records, deploy behind HTTPS, replace the shared demo student password, use unique strong passwords, restrict network access, and protect the server, data files, backups, and device with suitable access controls and encryption.
