@echo off
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 goto missing_node

echo Starting Campus One...
echo Open http://127.0.0.1:3000 in your browser.
echo Press Ctrl+C to stop the server.
echo.
node backend\server.js
if errorlevel 1 (
  echo.
  echo Campus One stopped with an error.
  pause
)
exit /b

:missing_node
echo Node.js is required. Install Node.js 20 or newer, then run start.bat again.
pause
exit /b 1
