const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

const ROOT = path.resolve(__dirname, "..");
const PUBLIC_DIR = path.join(ROOT, "frontend");
const DATABASE_DIR = path.join(ROOT, "database");
const SEED_FILE = path.join(DATABASE_DIR, "dataset", "demo-seed.json");
const DATA_FILE = process.env.DATA_FILE || path.join(DATABASE_DIR, "campus.json");
const STUDENT_AUTH_FILE = process.env.STUDENT_AUTH_FILE || path.join(DATABASE_DIR, "student-credentials.json");
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || "127.0.0.1";
const SESSION_TTL = 8 * 60 * 60 * 1000;
const COOKIE_NAME = "campus_one_session";
const STUDENT_COOKIE_NAME = "campus_one_student_session";
const DEFAULT_STUDENT_PASSWORD = process.env.STUDENT_PASSWORD || "Student2026!";
const STATUSES = new Set(["present", "absent", "late"]);
const NOTICE_TYPES = new Set(["announcement", "homework", "event", "update"]);
const email = (process.env.TEACHER_EMAIL || "teacher@school.com").toLowerCase();
const password = process.env.TEACHER_PASSWORD || "Attend2026!";
const passwordSalt = crypto.randomBytes(16);
const passwordHash = crypto.scryptSync(password, passwordSalt, 64);
const sessions = new Map();
const studentSessions = new Map();
const loginAttempts = new Map();
let needsMigration = false;

function makeId() {
  return crypto.randomUUID();
}

function initialData() {
  const seed = JSON.parse(fs.readFileSync(SEED_FILE, "utf8"));
  const classes = seed.classes;
  const students = [];
  seed.students.forEach((group) => {
    group.names.forEach((name, index) => {
      students.push({
        id: makeId(),
        name,
        classId: group.classId,
        rollNumber: String(index + 1).padStart(2, "0"),
      });
    });
  });

  const attendance = {};
  const today = new Date();
  for (let offset = 0; offset < 14; offset += 1) {
    const date = new Date(today);
    date.setDate(today.getDate() - offset);
    if (date.getDay() === 0 || date.getDay() === 6) continue;
    const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
    attendance[key] = {};
    students.forEach((student, index) => {
      const seed = index * 7 + offset * 11;
      attendance[key][student.id] = seed % 19 === 0 ? "absent" : seed % 13 === 0 ? "late" : "present";
    });
  }
  const notices = seed.notices.map((notice) => ({
    ...notice,
    id: makeId(),
    createdAt: daysAgo(notice.daysAgo),
  }));
  const library = seed.library.map((item) => ({ ...item, id: makeId() }));
  const books = seed.books.map((book) => ({ ...book }));
  const feeInvoices = createFeeInvoices(students, classes, seed.feeSchedule);
  return { classes, students, attendance, notices, library, books, loans: [], feeInvoices, feePaymentSimulations: [] };
}

function createFeeInvoices(students, classes, feeSchedule) {
  return students.flatMap((student) => {
    const grade = classes.find((item) => item.id === student.classId)?.grade;
    const gradeFees = feeSchedule.filter((item) => item.grade === grade);
    const defaultFees = feeSchedule.filter((item) => item.grade === "default");
    const sharedFees = feeSchedule.filter((item) => item.grade === "all");
    return [...(gradeFees.length ? gradeFees : defaultFees), ...sharedFees]
      .map((item) => ({
        id: makeId(),
        studentId: student.id,
        title: item.title,
        term: item.term,
        amountPaise: item.amountPaise,
        dueDate: item.dueDate,
      }));
  });
}

function daysAgo(days) {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return date.toISOString();
}

function loadData() {
  try {
    const parsed = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    if (isValidData(parsed)) {
      const migrated = migrateData(parsed);
      needsMigration = JSON.stringify(parsed) !== JSON.stringify(migrated);
      return migrated;
    }
    console.error("Attendance data has an invalid shape; keeping it unchanged and using sample data in memory.");
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
  return initialData();
}

function migrateData(value) {
  const next = { ...value };
  next.notices = Array.isArray(next.notices) ? next.notices : initialData().notices;
  next.library = Array.isArray(next.library) ? next.library : initialData().library;
  const seed = JSON.parse(fs.readFileSync(SEED_FILE, "utf8"));
  next.books = Array.isArray(next.books) ? next.books : seed.books.map((book) => ({ ...book }));
  next.loans = Array.isArray(next.loans) ? next.loans : [];
  next.feeInvoices = Array.isArray(next.feeInvoices)
    ? next.feeInvoices
    : createFeeInvoices(next.students, next.classes, seed.feeSchedule);
  next.feePaymentSimulations = Array.isArray(next.feePaymentSimulations) ? next.feePaymentSimulations : [];
  const oldNames = new Set(["Maple", "Cedar", "Willow"]);
  if (next.classes.some((item) => oldNames.has(item.name))) {
    const updated = [
      { name: "Computer Science", grade: "Year 1" },
      { name: "Business Studies", grade: "Year 2" },
      { name: "Visual Design", grade: "Year 3" },
    ];
    next.classes.forEach((item, index) => {
      if (updated[index]) Object.assign(item, updated[index]);
    });
  }
  return next;
}

let data = loadData();
if (needsMigration) {
  persistDataFile(data);
  needsMigration = false;
}
let studentCredentials = loadStudentCredentials();
ensureStudentCredentials(data.students);

function isValidData(value) {
  if (!value || !Array.isArray(value.classes) || !Array.isArray(value.students) ||
      !value.attendance || typeof value.attendance !== "object" || Array.isArray(value.attendance)) return false;
  const classIds = new Set(value.classes.map((item) => item && item.id));
  const studentIds = new Set(value.students.map((item) => item && item.id));
  if (classIds.size !== value.classes.length || studentIds.size !== value.students.length) return false;
  if (!value.classes.every((item) => item && typeof item.id === "string" && typeof item.name === "string" && typeof item.grade === "string")) return false;
  if (!value.students.every((item) => item && typeof item.id === "string" && typeof item.name === "string" &&
      typeof item.rollNumber === "string" && classIds.has(item.classId))) return false;
  const validAttendance = Object.entries(value.attendance).every(([date, records]) =>
    /^\d{4}-\d{2}-\d{2}$/.test(date) && records && typeof records === "object" && !Array.isArray(records) &&
    Object.entries(records).every(([studentId, status]) => studentIds.has(studentId) && STATUSES.has(status)));
  if (!validAttendance) return false;
  if (value.notices !== undefined && (!Array.isArray(value.notices) || !value.notices.every((notice) =>
    notice && typeof notice.id === "string" && NOTICE_TYPES.has(notice.type) && typeof notice.title === "string" &&
    typeof notice.body === "string" && (notice.classId === null || classIds.has(notice.classId)) &&
    typeof notice.author === "string" && typeof notice.createdAt === "string"))) return false;
  if (value.library !== undefined && (!Array.isArray(value.library) || !value.library.every((item) => {
    if (!item || typeof item.id !== "string" || typeof item.title !== "string" || typeof item.author !== "string" ||
        typeof item.category !== "string" || typeof item.description !== "string" || typeof item.url !== "string" ||
        typeof item.format !== "string") return false;
    try { return ["http:", "https:"].includes(new URL(item.url).protocol); } catch { return false; }
  }))) return false;
  if (value.books !== undefined && (!Array.isArray(value.books) || !value.books.every((book) =>
    book && typeof book.id === "string" && typeof book.title === "string" && typeof book.author === "string" &&
    typeof book.genre === "string" && typeof book.isbn === "string" && Number.isInteger(book.totalCopies) && book.totalCopies > 0))) return false;
  if (value.loans !== undefined) {
    const bookIds = new Set((value.books || []).map((book) => book.id));
    const loanIds = new Set();
    if (!Array.isArray(value.loans) || !value.loans.every((loan) => {
      if (!loan || typeof loan.id !== "string" || loanIds.has(loan.id) ||
          !studentIds.has(loan.studentId) || !bookIds.has(loan.bookId) ||
          typeof loan.issuedAt !== "string" || typeof loan.dueAt !== "string" ||
          !(loan.returnedAt === null || typeof loan.returnedAt === "string")) return false;
      loanIds.add(loan.id);
      return true;
    })) return false;
  }
  if (value.feeInvoices !== undefined) {
    const invoiceIds = new Set();
    if (!Array.isArray(value.feeInvoices) || !value.feeInvoices.every((invoice) => {
      if (!invoice || typeof invoice.id !== "string" || invoiceIds.has(invoice.id) ||
          !studentIds.has(invoice.studentId) || typeof invoice.title !== "string" ||
          typeof invoice.term !== "string" || !Number.isSafeInteger(invoice.amountPaise) ||
          invoice.amountPaise <= 0 || !/^\d{4}-\d{2}-\d{2}$/.test(invoice.dueDate)) return false;
      invoiceIds.add(invoice.id);
      return true;
    })) return false;
  }
  if (value.feePaymentSimulations !== undefined) {
    const invoices = new Map((value.feeInvoices || []).map((invoice) => [invoice.id, invoice]));
    const simulationIds = new Set();
    if (!Array.isArray(value.feePaymentSimulations) || !value.feePaymentSimulations.every((simulation) => {
      const invoice = simulation && invoices.get(simulation.invoiceId);
      if (!simulation || typeof simulation.id !== "string" || simulationIds.has(simulation.id) ||
          !invoice || !studentIds.has(simulation.studentId) || invoice.studentId !== simulation.studentId ||
          !Number.isSafeInteger(simulation.amountPaise) || simulation.amountPaise <= 0 ||
          simulation.amountPaise > invoice.amountPaise || simulation.status !== "simulation_only" ||
          typeof simulation.reference !== "string" || typeof simulation.submittedAt !== "string") return false;
      simulationIds.add(simulation.id);
      return true;
    })) return false;
  }
  return true;
}

function persistDataFile(next) {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true, mode: 0o700 });
  const temporary = `${DATA_FILE}.${process.pid}.${crypto.randomBytes(4).toString("hex")}.tmp`;
  try {
    fs.writeFileSync(temporary, JSON.stringify(next, null, 2), { mode: 0o600 });
    fs.renameSync(temporary, DATA_FILE);
    try { fs.chmodSync(DATA_FILE, 0o600); } catch { /* Windows uses its own ACL model. */ }
  } finally {
    if (fs.existsSync(temporary)) fs.unlinkSync(temporary);
  }
}

function loadStudentCredentials() {
  try {
    const stored = JSON.parse(fs.readFileSync(STUDENT_AUTH_FILE, "utf8"));
    if (!stored || typeof stored !== "object" || Array.isArray(stored) ||
        !Object.entries(stored).every(([, credential]) =>
          credential && typeof credential.email === "string" && /^[a-f0-9]{32}$/i.test(credential.salt) &&
          /^[a-f0-9]{128}$/i.test(credential.hash))) {
      throw new Error("Student credentials file has an invalid shape.");
    }
    return stored;
  } catch (error) {
    if (error.code === "ENOENT") return {};
    throw error;
  }
}

function persistStudentCredentials(next) {
  fs.mkdirSync(path.dirname(STUDENT_AUTH_FILE), { recursive: true, mode: 0o700 });
  const temporary = `${STUDENT_AUTH_FILE}.${process.pid}.${crypto.randomBytes(4).toString("hex")}.tmp`;
  try {
    fs.writeFileSync(temporary, JSON.stringify(next, null, 2), { mode: 0o600 });
    fs.renameSync(temporary, STUDENT_AUTH_FILE);
    try { fs.chmodSync(STUDENT_AUTH_FILE, 0o600); } catch { /* Windows uses its own ACL model. */ }
  } finally {
    if (fs.existsSync(temporary)) fs.unlinkSync(temporary);
  }
}

function studentEmailFromName(student) {
  const name = student.name.normalize("NFKD").replace(/[\u0300-\u036f]/g, "")
    .toLowerCase().replace(/[^a-z0-9]+/g, ".").replace(/^\.+|\.+$/g, "");
  return `${name}.${student.rollNumber}@students.campusone.edu`;
}

function ensureStudentCredentials(students) {
  const next = { ...studentCredentials };
  const usedEmails = new Set(Object.values(next).map((credential) => credential.email.toLowerCase()));
  let changed = false;
  students.forEach((student) => {
    if (next[student.id]) return;
    const baseEmail = studentEmailFromName(student);
    let accountEmail = baseEmail;
    let suffix = 2;
    while (usedEmails.has(accountEmail.toLowerCase())) {
      const local = baseEmail.slice(0, baseEmail.lastIndexOf("@"));
      accountEmail = `${local}.${suffix}@students.campusone.edu`;
      suffix += 1;
    }
    const salt = crypto.randomBytes(16);
    next[student.id] = {
      email: accountEmail,
      salt: salt.toString("hex"),
      hash: crypto.scryptSync(DEFAULT_STUDENT_PASSWORD, salt, 64).toString("hex"),
    };
    usedEmails.add(accountEmail.toLowerCase());
    changed = true;
  });
  if (changed) {
    persistStudentCredentials(next);
    studentCredentials = next;
  }
}

function reconcileStudentFees(next) {
  if (!next || typeof next !== "object" || !Array.isArray(next.students) || !Array.isArray(next.classes) ||
      !next.students.every((student) => student && typeof student.id === "string") ||
      !next.classes.every((item) => item && typeof item.id === "string" && typeof item.grade === "string") ||
      (next.feeInvoices !== undefined && (!Array.isArray(next.feeInvoices) ||
        next.feeInvoices.some((invoice) => !invoice || typeof invoice.studentId !== "string"))) ||
      (next.feePaymentSimulations !== undefined && (!Array.isArray(next.feePaymentSimulations) ||
        next.feePaymentSimulations.some((simulation) => !simulation ||
          typeof simulation.studentId !== "string" || typeof simulation.invoiceId !== "string")))) return next;
  const studentIds = new Set(next.students.map((student) => student.id));
  const feeInvoices = (next.feeInvoices || []).filter((invoice) => studentIds.has(invoice.studentId));
  const invoicedStudents = new Set(feeInvoices.map((invoice) => invoice.studentId));
  const newStudents = next.students.filter((student) => !invoicedStudents.has(student.id));
  if (newStudents.length) {
    const seed = JSON.parse(fs.readFileSync(SEED_FILE, "utf8"));
    feeInvoices.push(...createFeeInvoices(newStudents, next.classes, seed.feeSchedule));
  }
  const invoiceIds = new Set(feeInvoices.map((invoice) => invoice.id));
  const feePaymentSimulations = (next.feePaymentSimulations || []).filter((simulation) =>
    studentIds.has(simulation.studentId) && invoiceIds.has(simulation.invoiceId));
  return { ...next, feeInvoices, feePaymentSimulations };
}

function saveData(next) {
  next = reconcileStudentFees(next);
  if (!isValidData(next)) {
    const error = new Error("Attendance data did not pass validation.");
    error.statusCode = 400;
    throw error;
  }
  persistDataFile(next);
  data = next;
  ensureStudentCredentials(data.students);
}

function sendJson(response, statusCode, value, headers = {}) {
  response.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    ...headers,
  });
  response.end(JSON.stringify(value));
}

function readJson(request, maxBytes = 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let body = "";
    let bytes = 0;
    request.setEncoding("utf8");
    request.on("data", (chunk) => {
      bytes += Buffer.byteLength(chunk);
      if (bytes > maxBytes) {
        const error = new Error("Request body is too large.");
        error.statusCode = 413;
        reject(error);
        request.destroy();
        return;
      }
      body += chunk;
    });
    request.on("end", () => {
      try { resolve(JSON.parse(body || "{}")); }
      catch {
        const error = new Error("Request body must be valid JSON.");
        error.statusCode = 400;
        reject(error);
      }
    });
    request.on("error", reject);
  });
}

function cookieValue(request, name) {
  const cookies = (request.headers.cookie || "").split(";");
  for (const cookie of cookies) {
    const separator = cookie.indexOf("=");
    if (separator < 0) continue;
    if (cookie.slice(0, separator).trim() === name) return cookie.slice(separator + 1).trim();
  }
  return "";
}

function getSession(request) {
  const token = cookieValue(request, COOKIE_NAME);
  const session = sessions.get(token);
  if (!session) return null;
  if (session.expiresAt < Date.now()) {
    sessions.delete(token);
    return null;
  }
  return { token, session };
}

function getStudentSession(request) {
  const token = cookieValue(request, STUDENT_COOKIE_NAME);
  const session = studentSessions.get(token);
  if (!session) return null;
  if (session.expiresAt < Date.now() || !data.students.some((student) => student.id === session.studentId)) {
    studentSessions.delete(token);
    return null;
  }
  return { token, session };
}

function safeStudent(studentId) {
  const student = data.students.find((item) => item.id === studentId);
  if (!student) return null;
  const credential = studentCredentials[studentId];
  return {
    id: student.id,
    name: student.name,
    classId: student.classId,
    rollNumber: student.rollNumber,
    email: credential.email,
  };
}

function verifyStudentPassword(studentId, suppliedPassword) {
  const credential = studentCredentials[studentId];
  const salt = credential ? Buffer.from(credential.salt, "hex") : Buffer.alloc(16);
  const expected = credential ? Buffer.from(credential.hash, "hex") : crypto.scryptSync("invalid-student-password", salt, 64);
  const candidate = crypto.scryptSync(String(suppliedPassword).slice(0, 1024), salt, 64);
  return credential && crypto.timingSafeEqual(candidate, expected);
}

function attendanceForStudent(studentId) {
  return Object.entries(data.attendance)
    .filter(([, records]) => records[studentId])
    .map(([date, records]) => ({ date, status: records[studentId] }))
    .sort((a, b) => b.date.localeCompare(a.date));
}

function availableCopies(bookId) {
  const book = data.books.find((item) => item.id === bookId);
  if (!book) return 0;
  const issued = data.loans.filter((loan) => loan.bookId === bookId && !loan.returnedAt).length;
  return Math.max(0, book.totalCopies - issued);
}

function assertSameOrigin(request) {
  const origin = request.headers.origin;
  if (!origin) return;
  try {
    if (new URL(origin).host !== request.headers.host) {
      const error = new Error("Cross-origin requests are not allowed.");
      error.statusCode = 403;
      throw error;
    }
  } catch (error) {
    if (error.statusCode) throw error;
    const invalidOrigin = new Error("Invalid request origin.");
    invalidOrigin.statusCode = 403;
    throw invalidOrigin;
  }
}

function checkLoginLimit(ip) {
  const now = Date.now();
  const entry = loginAttempts.get(ip);
  if (!entry || entry.resetAt < now) {
    loginAttempts.set(ip, { count: 0, resetAt: now + 15 * 60 * 1000 });
    return;
  }
  if (entry.count >= 8) {
    const error = new Error("Too many sign-in attempts. Try again in 15 minutes.");
    error.statusCode = 429;
    throw error;
  }
}

function staticFile(request, response, pathname) {
  const requested = pathname === "/" ? "/index.html" : decodeURIComponent(pathname);
  const resolved = path.resolve(PUBLIC_DIR, `.${requested}`);
  if (!resolved.startsWith(`${PUBLIC_DIR}${path.sep}`)) {
    response.writeHead(403);
    response.end("Forbidden");
    return;
  }
  fs.readFile(resolved, (error, content) => {
    if (error) {
      response.writeHead(error.code === "ENOENT" ? 404 : 500);
      response.end(error.code === "ENOENT" ? "Not found" : "Unable to read file");
      return;
    }
    const extension = path.extname(resolved).toLowerCase();
    const types = {
      ".html": "text/html; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".js": "text/javascript; charset=utf-8",
      ".svg": "image/svg+xml",
      ".png": "image/png",
      ".ico": "image/x-icon",
    };
    response.writeHead(200, {
      "Content-Type": types[extension] || "application/octet-stream",
      "Cache-Control": "no-cache",
      "X-Content-Type-Options": "nosniff",
      "Content-Security-Policy": "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
      "Referrer-Policy": "same-origin",
    });
    response.end(content);
  });
}

async function handle(request, response) {
  const url = new URL(request.url, `http://${request.headers.host || "localhost"}`);
  const { pathname } = url;
  if (!pathname.startsWith("/api/")) {
    staticFile(request, response, pathname);
    return;
  }

  try {
    if (request.method !== "GET") assertSameOrigin(request);
    if (pathname === "/api/student/login" && request.method === "POST") {
      const ip = `student:${request.socket.remoteAddress || "unknown"}`;
      checkLoginLimit(ip);
      const body = await readJson(request, 4096);
      const suppliedEmail = typeof body.email === "string" ? body.email.toLowerCase().trim() : "";
      const studentId = Object.keys(studentCredentials).find((id) =>
        studentCredentials[id].email.toLowerCase() === suppliedEmail);
      const suppliedPassword = typeof body.password === "string" ? body.password : "";
      const valid = verifyStudentPassword(studentId, suppliedPassword);
      if (!valid) {
        loginAttempts.get(ip).count += 1;
        sendJson(response, 401, { error: "Student email or password is incorrect." });
        return;
      }
      const teacher = getSession(request);
      if (teacher) sessions.delete(teacher.token);
      loginAttempts.delete(ip);
      const token = crypto.randomBytes(32).toString("hex");
      studentSessions.set(token, { studentId, expiresAt: Date.now() + SESSION_TTL });
      const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
      sendJson(response, 200, { user: { ...safeStudent(studentId), role: "student" } }, {
        "Set-Cookie": [
          `${STUDENT_COOKIE_NAME}=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_TTL / 1000}${secure}`,
          `${COOKIE_NAME}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${secure}`,
        ],
      });
      return;
    }
    if (pathname === "/api/student/me" && request.method === "GET") {
      const current = getStudentSession(request);
      sendJson(response, current ? 200 : 401, current ?
        { user: { ...safeStudent(current.session.studentId), role: "student" } } : { error: "Not signed in." });
      return;
    }
    if (pathname === "/api/student/logout" && request.method === "POST") {
      const current = getStudentSession(request);
      if (current) studentSessions.delete(current.token);
      sendJson(response, 200, { ok: true }, {
        "Set-Cookie": `${STUDENT_COOKIE_NAME}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0`,
      });
      return;
    }
    if (pathname.startsWith("/api/student/") && pathname !== "/api/student/accounts") {
      const current = getStudentSession(request);
      if (!current) {
        sendJson(response, 401, { error: "Your student session has expired. Please sign in again." });
        return;
      }
      const studentId = current.session.studentId;
      if (pathname === "/api/student/data" && request.method === "GET") {
        const student = data.students.find((item) => item.id === studentId);
        const course = data.classes.find((item) => item.id === student.classId);
        sendJson(response, 200, {
          student: safeStudent(studentId),
          course,
          attendance: attendanceForStudent(studentId),
          notices: (data.notices || []).filter((notice) => notice.classId === null || notice.classId === student.classId),
          feeInvoices: data.feeInvoices.filter((invoice) => invoice.studentId === studentId),
          feePaymentSimulations: data.feePaymentSimulations.filter((simulation) => simulation.studentId === studentId),
          books: data.books.map((book) => ({ ...book, availableCopies: availableCopies(book.id) })),
          loans: data.loans.filter((loan) => loan.studentId === studentId),
        });
        return;
      }
      if (pathname === "/api/student/fee-payments" && request.method === "POST") {
        const body = await readJson(request, 4096);
        if (!body || typeof body !== "object" || Array.isArray(body) ||
            typeof body.invoiceId !== "string" || !Number.isSafeInteger(body.amountPaise) ||
            body.amountPaise <= 0) {
          sendJson(response, 400, { error: "Choose a fee item and enter a valid simulation amount." });
          return;
        }
        const invoice = data.feeInvoices.find((item) => item.id === body.invoiceId && item.studentId === studentId);
        if (!invoice) {
          sendJson(response, 404, { error: "That fee item was not found." });
          return;
        }
        if (!Number.isSafeInteger(body.amountPaise) || body.amountPaise <= 0 || body.amountPaise > invoice.amountPaise) {
          sendJson(response, 400, { error: "Enter a valid simulation amount no greater than the outstanding fee." });
          return;
        }
        const payment = {
          id: makeId(),
          studentId,
          invoiceId: invoice.id,
          amountPaise: body.amountPaise,
          submittedAt: new Date().toISOString(),
          status: "simulation_only",
          reference: `SIM-${crypto.randomBytes(4).toString("hex").toUpperCase()}`,
        };
        saveData({ ...data, feePaymentSimulations: [...data.feePaymentSimulations, payment] });
        sendJson(response, 201, {
          payment,
          message: "Simulation recorded. No real payment was processed and the balance is unchanged.",
        });
        return;
      }
      if (pathname === "/api/student/loans" && request.method === "POST") {
        const body = await readJson(request, 4096);
        const book = data.books.find((item) => item.id === body.bookId);
        if (!book) {
          sendJson(response, 404, { error: "That book is not in the catalogue." });
          return;
        }
        const activeLoans = data.loans.filter((loan) => loan.studentId === studentId && !loan.returnedAt);
        if (activeLoans.length >= 3) {
          sendJson(response, 409, { error: "You have reached the limit of three active books. Return one before borrowing another." });
          return;
        }
        if (activeLoans.some((loan) => loan.bookId === book.id)) {
          sendJson(response, 409, { error: "You already have this title checked out." });
          return;
        }
        if (availableCopies(book.id) <= 0) {
          sendJson(response, 409, { error: "All copies are currently issued. Please check back soon." });
          return;
        }
        const issuedAt = new Date();
        const dueDate = new Date(issuedAt);
        dueDate.setDate(dueDate.getDate() + 14);
        const loan = {
          id: makeId(),
          bookId: book.id,
          studentId,
          issuedAt: issuedAt.toISOString(),
          dueAt: dueDate.toISOString(),
          returnedAt: null,
        };
        saveData({ ...data, loans: [...data.loans, loan] });
        sendJson(response, 201, { loan, book, availableCopies: availableCopies(book.id) });
        return;
      }
      const returnMatch = pathname.match(/^\/api\/student\/loans\/([a-f0-9-]+)\/return$/i);
      if (returnMatch && request.method === "POST") {
        const loan = data.loans.find((item) => item.id === returnMatch[1] && item.studentId === studentId);
        if (!loan) {
          sendJson(response, 404, { error: "That book loan was not found." });
          return;
        }
        if (loan.returnedAt) {
          sendJson(response, 409, { error: "This book has already been returned." });
          return;
        }
        const returnedLoan = { ...loan, returnedAt: new Date().toISOString() };
        saveData({ ...data, loans: data.loans.map((item) => item.id === loan.id ? returnedLoan : item) });
        sendJson(response, 200, { loan: returnedLoan });
        return;
      }
      if (pathname === "/api/student/password" && request.method === "POST") {
        const body = await readJson(request, 4096);
        const currentPassword = typeof body.currentPassword === "string" ? body.currentPassword : "";
        const newPassword = typeof body.newPassword === "string" ? body.newPassword : "";
        if (!verifyStudentPassword(studentId, currentPassword)) {
          sendJson(response, 400, { error: "Your current password is incorrect." });
          return;
        }
        if (newPassword.length < 12 || newPassword.length > 1024) {
          sendJson(response, 400, { error: "Choose a new password with at least 12 characters." });
          return;
        }
        const salt = crypto.randomBytes(16);
        const nextCredentials = {
          ...studentCredentials,
          [studentId]: {
            ...studentCredentials[studentId],
            salt: salt.toString("hex"),
            hash: crypto.scryptSync(newPassword, salt, 64).toString("hex"),
          },
        };
        persistStudentCredentials(nextCredentials);
        studentCredentials = nextCredentials;
        sendJson(response, 200, { ok: true });
        return;
      }
      sendJson(response, 404, { error: "Student endpoint not found." });
      return;
    }
    if (pathname === "/api/login" && request.method === "POST") {
      const ip = request.socket.remoteAddress || "unknown";
      checkLoginLimit(ip);
      const body = await readJson(request, 4096);
      const suppliedEmail = typeof body.email === "string" ? body.email.toLowerCase().trim() : "";
      const suppliedPassword = typeof body.password === "string" ? body.password : "";
      const candidate = crypto.scryptSync(suppliedPassword.slice(0, 1024), passwordSalt, 64);
      const valid = suppliedEmail === email && crypto.timingSafeEqual(candidate, passwordHash);
      if (!valid) {
        loginAttempts.get(ip).count += 1;
        sendJson(response, 401, { error: "Email or password is incorrect." });
        return;
      }
      loginAttempts.delete(ip);
      const token = crypto.randomBytes(32).toString("hex");
      sessions.set(token, { email, expiresAt: Date.now() + SESSION_TTL });
      const student = getStudentSession(request);
      if (student) studentSessions.delete(student.token);
      const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
      sendJson(response, 200, { user: { email } }, {
        "Set-Cookie": [
          `${COOKIE_NAME}=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_TTL / 1000}${secure}`,
          `${STUDENT_COOKIE_NAME}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${secure}`,
        ],
      });
      return;
    }
    if (pathname === "/api/logout" && request.method === "POST") {
      const current = getSession(request);
      if (current) sessions.delete(current.token);
      sendJson(response, 200, { ok: true }, {
        "Set-Cookie": [
          `${COOKIE_NAME}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0`,
          `${STUDENT_COOKIE_NAME}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0`,
        ],
      });
      return;
    }
    if (pathname === "/api/me" && request.method === "GET") {
      const current = getSession(request);
      sendJson(response, current ? 200 : 401, current ? { user: { email: current.session.email } } : { error: "Not signed in." });
      return;
    }
    if (pathname.startsWith("/api/")) {
      const current = getSession(request);
      if (!current) {
        sendJson(response, 401, { error: "Your session has expired. Please sign in again." });
        return;
      }
    }
    if (pathname === "/api/student/accounts" && request.method === "GET") {
      sendJson(response, 200, {
        accounts: data.students.map((student) => ({
          studentId: student.id,
          email: studentCredentials[student.id].email,
        })),
      });
      return;
    }
    if (pathname === "/api/data" && request.method === "GET") {
      sendJson(response, 200, data);
      return;
    }
    if (pathname === "/api/data" && request.method === "PUT") {
      const next = await readJson(request);
      saveData(next);
      sendJson(response, 200, { ok: true });
      return;
    }
    if (pathname === "/api/notices" && request.method === "POST") {
      const body = await readJson(request, 16384);
      const activeSession = getSession(request);
      const type = typeof body.type === "string" ? body.type : "";
      const title = typeof body.title === "string" ? body.title.trim() : "";
      const message = typeof body.body === "string" ? body.body.trim() : "";
      const classId = body.classId === "all" || body.classId === "" || body.classId === undefined ? null : body.classId;
      if (!NOTICE_TYPES.has(type) || title.length < 3 || title.length > 120 || message.length < 3 || message.length > 2000 ||
          (classId !== null && !data.classes.some((item) => item.id === classId))) {
        sendJson(response, 400, { error: "Add a valid notice type, title, message, and classroom." });
        return;
      }
      const notice = { id: makeId(), type, title, body: message, classId, author: activeSession.session.email, createdAt: new Date().toISOString() };
      saveData({ ...data, notices: [notice, ...(data.notices || [])] });
      sendJson(response, 201, { notice });
      return;
    }
    sendJson(response, 404, { error: "Endpoint not found." });
  } catch (error) {
    if (error.statusCode >= 500 || !error.statusCode) console.error(error);
    sendJson(response, error.statusCode || 500, {
      error: error.statusCode ? error.message : "Something went wrong. Please try again.",
    });
  }
}

const server = http.createServer((request, response) => {
  handle(request, response);
});

server.listen(PORT, HOST, () => {
  console.log(`Campus One is ready at http://${HOST}:${PORT}`);
  console.log(`Teacher sign-in: ${email}`);
  if (!process.env.TEACHER_PASSWORD) console.log("Demo password: Attend2026!");
  const demoStudent = data.students.find((student) =>
    verifyStudentPassword(student.id, DEFAULT_STUDENT_PASSWORD));
  if (demoStudent) {
    console.log(`Student sign-in: ${studentCredentials[demoStudent.id].email}`);
    console.log(`Student starter password: ${DEFAULT_STUDENT_PASSWORD}`);
  } else {
    console.log("Student starter sign-in: no account is using the configured starter password.");
  }
});
