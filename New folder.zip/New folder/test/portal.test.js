const test = require("node:test");
const assert = require("node:assert/strict");
const { spawn } = require("node:child_process");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const net = require("node:net");

const root = path.resolve(__dirname, "..");
const temporaryDirectory = fs.mkdtempSync(path.join(os.tmpdir(), "campus-one-test-"));
const dataFile = path.join(temporaryDirectory, "campus.json");
const testEmail = "faculty@test.example";
const testPassword = "TestCampusOne!2468";
const studentPassword = "Student2026!";
const changedStudentPassword = "ChangedCampus!2026";
let port;
let child;
let output = "";

async function unusedPort() {
  const listener = net.createServer();
  await new Promise((resolve, reject) => {
    listener.once("error", reject);
    listener.listen(0, "127.0.0.1", resolve);
  });
  const address = listener.address();
  await new Promise((resolve, reject) => listener.close((error) => error ? reject(error) : resolve()));
  return address.port;
}

function startServer() {
  child = spawn(process.execPath, [path.join(root, "backend", "server.js")], {
    cwd: root,
    env: {
      ...process.env,
      HOST: "127.0.0.1",
      PORT: String(port),
      DATA_FILE: dataFile,
      STUDENT_AUTH_FILE: path.join(temporaryDirectory, "student-credentials.json"),
      TEACHER_EMAIL: testEmail,
      TEACHER_PASSWORD: testPassword,
      STUDENT_PASSWORD: studentPassword,
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  child.stdout.on("data", (chunk) => { output += chunk.toString(); });
  child.stderr.on("data", (chunk) => { output += chunk.toString(); });
  return new Promise(async (resolve, reject) => {
    const deadline = Date.now() + 10000;
    while (Date.now() < deadline) {
      if (child.exitCode !== null) {
        reject(new Error(`Server exited before starting:\n${output}`));
        return;
      }
      try {
        const response = await fetch(`http://127.0.0.1:${port}/api/me`);
        if (response.status === 401) {
          resolve();
          return;
        }
      } catch { /* The server is still starting. */ }
      await new Promise((done) => setTimeout(done, 75));
    }
    reject(new Error(`Server did not start in time:\n${output}`));
  });
}

async function stopServer() {
  if (!child || child.exitCode !== null) return;
  const processDone = new Promise((resolve) => child.once("exit", resolve));
  child.kill();
  await processDone;
  child = null;
}

test("Campus One protects data, publishes validated notices, and persists portal data", async (t) => {
  port = await unusedPort();
  await startServer();
  t.after(async () => {
    await stopServer();
    fs.rmSync(temporaryDirectory, { recursive: true, force: true });
  });
  assert.match(output, /Student sign-in: ava\.thompson\.01@students\.campusone\.edu/);
  assert.match(output, /Student starter password: Student2026!/);

  const baseUrl = `http://127.0.0.1:${port}`;
  const unauthenticated = await fetch(`${baseUrl}/api/data`);
  assert.equal(unauthenticated.status, 401);

  const wrongLogin = await fetch(`${baseUrl}/api/login`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ email: testEmail, password: "incorrect" }),
  });
  assert.equal(wrongLogin.status, 401);

  const login = await fetch(`${baseUrl}/api/login`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ email: testEmail, password: testPassword }),
  });
  assert.equal(login.status, 200);
  const cookie = login.headers.get("set-cookie");
  assert.match(cookie, /HttpOnly/i);
  assert.match(cookie, /SameSite=Strict/i);
  const headers = { cookie: cookie.split(";")[0] };

  const dataResponse = await fetch(`${baseUrl}/api/data`, { headers });
  assert.equal(dataResponse.status, 200);
  const data = await dataResponse.json();
  assert.equal(data.classes.length, 3);
  assert.equal(data.students.length, 21);
  assert.ok(data.library.length >= 5);
  assert.ok(data.books.length >= 5);
  assert.ok(data.notices.length >= 5);
  assert.ok(data.feeInvoices.length >= data.students.length * 2);
  const date = new Date();
  const today = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  const firstStudent = data.students[0];
  data.attendance[today] = { ...(data.attendance[today] || {}), [firstStudent.id]: "late" };
  const saveAttendance = await fetch(`${baseUrl}/api/data`, {
    method: "PUT",
    headers: { ...headers, "content-type": "application/json" },
    body: JSON.stringify(data),
  });
  assert.equal(saveAttendance.status, 200);

  const newlyEnrolled = {
    id: "new-fee-student",
    name: "Jordan Example",
    classId: data.classes[0].id,
    rollNumber: "99",
  };
  const addStudent = await fetch(`${baseUrl}/api/data`, {
    method: "PUT",
    headers: { ...headers, "content-type": "application/json" },
    body: JSON.stringify({ ...data, students: [...data.students, newlyEnrolled] }),
  });
  assert.equal(addStudent.status, 200);
  const rosterResponse = await fetch(`${baseUrl}/api/data`, { headers });
  const roster = await rosterResponse.json();
  assert.equal(roster.feeInvoices.filter((invoice) => invoice.studentId === newlyEnrolled.id).length, 2);

  const accountResponse = await fetch(`${baseUrl}/api/student/accounts`, { headers });
  assert.equal(accountResponse.status, 200);
  const accounts = await accountResponse.json();
  const student = data.students[0];
  const studentEmail = accounts.accounts.find((account) => account.studentId === student.id).email;
  assert.equal(studentEmail, "ava.thompson.01@students.campusone.edu");

  const studentLogin = await fetch(`${baseUrl}/api/student/login`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ email: studentEmail, password: studentPassword }),
  });
  assert.equal(studentLogin.status, 200);
  const studentCookie = studentLogin.headers.getSetCookie().find((value) => value.startsWith("campus_one_student_session="));
  assert.match(studentCookie, /HttpOnly/i);
  const studentHeaders = { cookie: studentCookie.split(";")[0] };
  const studentDataResponse = await fetch(`${baseUrl}/api/student/data`, { headers: studentHeaders });
  const studentData = await studentDataResponse.json();
  assert.equal(studentData.student.id, student.id);
  assert.ok(studentData.attendance.some((record) => record.date === today && record.status === "late"));
  assert.ok(studentData.notices.some((item) => item.title === "Open Mic & Makers Night"));
  assert.ok(studentData.notices.some((item) => item.title === "Computer lab B is back online"));
  assert.ok(!studentData.notices.some((item) => item.title === "Introduction to Human-Centered Design"));
  assert.ok(studentData.feeInvoices.length > 0);
  assert.ok(studentData.feeInvoices.every((invoice) => invoice.studentId === student.id));
  assert.equal(studentData.feePaymentSimulations.length, 0);
  assert.equal((await fetch(`${baseUrl}/api/data`, { headers: studentHeaders })).status, 401);

  const feeInvoice = studentData.feeInvoices[0];
  const invalidFeePayment = await fetch(`${baseUrl}/api/student/fee-payments`, {
    method: "POST",
    headers: { ...studentHeaders, "content-type": "application/json" },
    body: JSON.stringify({ invoiceId: feeInvoice.id, amountPaise: 0 }),
  });
  assert.equal(invalidFeePayment.status, 400);
  const excessiveFeePayment = await fetch(`${baseUrl}/api/student/fee-payments`, {
    method: "POST",
    headers: { ...studentHeaders, "content-type": "application/json" },
    body: JSON.stringify({ invoiceId: feeInvoice.id, amountPaise: feeInvoice.amountPaise + 1 }),
  });
  assert.equal(excessiveFeePayment.status, 400);
  const otherStudentInvoice = data.feeInvoices.find((invoice) => invoice.studentId !== student.id);
  const privateFeePayment = await fetch(`${baseUrl}/api/student/fee-payments`, {
    method: "POST",
    headers: { ...studentHeaders, "content-type": "application/json" },
    body: JSON.stringify({ invoiceId: otherStudentInvoice.id, amountPaise: 100 }),
  });
  assert.equal(privateFeePayment.status, 404);
  const simulatedFeePayment = await fetch(`${baseUrl}/api/student/fee-payments`, {
    method: "POST",
    headers: { ...studentHeaders, "content-type": "application/json" },
    body: JSON.stringify({ invoiceId: feeInvoice.id, amountPaise: 5000 }),
  });
  assert.equal(simulatedFeePayment.status, 201);
  const { payment: simulation, message: simulationMessage } = await simulatedFeePayment.json();
  assert.equal(simulation.status, "simulation_only");
  assert.match(simulationMessage, /no real payment was processed/i);
  const refreshedFees = await fetch(`${baseUrl}/api/student/data`, { headers: studentHeaders });
  const refreshedFeeData = await refreshedFees.json();
  assert.equal(refreshedFeeData.feeInvoices.find((invoice) => invoice.id === feeInvoice.id).amountPaise, feeInvoice.amountPaise);
  assert.ok(refreshedFeeData.feePaymentSimulations.some((item) => item.id === simulation.id));

  const issued = await fetch(`${baseUrl}/api/student/loans`, {
    method: "POST",
    headers: { ...studentHeaders, "content-type": "application/json" },
    body: JSON.stringify({ bookId: data.books[0].id }),
  });
  assert.equal(issued.status, 201);
  const { loan } = await issued.json();

  const passwordUpdate = await fetch(`${baseUrl}/api/student/password`, {
    method: "POST",
    headers: { ...studentHeaders, "content-type": "application/json" },
    body: JSON.stringify({ currentPassword: studentPassword, newPassword: changedStudentPassword }),
  });
  assert.equal(passwordUpdate.status, 200);

  const invalidNotice = await fetch(`${baseUrl}/api/notices`, {
    method: "POST",
    headers: { ...headers, "content-type": "application/json" },
    body: JSON.stringify({ type: "homework", title: "Bad course", body: "Invalid audience", classId: "not-a-course" }),
  });
  assert.equal(invalidNotice.status, 400);

  const posted = await fetch(`${baseUrl}/api/notices`, {
    method: "POST",
    headers: { ...headers, "content-type": "application/json" },
    body: JSON.stringify({ type: "event", title: "Studio open house", body: "Join us in the design studio this Friday.", classId: "all" }),
  });
  assert.equal(posted.status, 201);
  const { notice } = await posted.json();
  assert.equal(notice.author, testEmail);
  assert.equal(notice.type, "event");

  const classNotice = await fetch(`${baseUrl}/api/notices`, {
    method: "POST",
    headers: { ...headers, "content-type": "application/json" },
    body: JSON.stringify({ type: "homework", title: "Year 3 studio prep", body: "Bring your draft.", classId: data.classes[2].id }),
  });
  assert.equal(classNotice.status, 201);

  const updatedStudentData = await fetch(`${baseUrl}/api/student/data`, { headers: studentHeaders });
  const updatedNotices = (await updatedStudentData.json()).notices;
  assert.ok(updatedNotices.some((item) => item.title === "Studio open house"));
  assert.ok(!updatedNotices.some((item) => item.title === "Year 3 studio prep"));

  await stopServer();
  await startServer();
  const persistedLogin = await fetch(`${baseUrl}/api/login`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ email: testEmail, password: testPassword }),
  });
  const persistedCookie = persistedLogin.headers.get("set-cookie");
  const persistedResponse = await fetch(`${baseUrl}/api/data`, {
    headers: { cookie: persistedCookie.split(";")[0] },
  });
  const persisted = await persistedResponse.json();
  assert.equal(persistedResponse.status, 200);
  assert.ok(persisted.notices.some((item) => item.title === "Studio open house"));
  assert.equal(persisted.library.length, data.library.length);
  assert.equal(persisted.attendance[today][firstStudent.id], "late");
  assert.ok(persisted.loans.some((item) => item.id === loan.id && item.studentId === student.id && !item.returnedAt));

  const oldStudentLogin = await fetch(`${baseUrl}/api/student/login`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ email: studentEmail, password: studentPassword }),
  });
  assert.equal(oldStudentLogin.status, 401);
  const newStudentLogin = await fetch(`${baseUrl}/api/student/login`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ email: studentEmail, password: changedStudentPassword }),
  });
  assert.equal(newStudentLogin.status, 200);
  const newStudentCookie = newStudentLogin.headers.getSetCookie().find((value) => value.startsWith("campus_one_student_session="));
  const persistedFeeData = await fetch(`${baseUrl}/api/student/data`, {
    headers: { cookie: newStudentCookie.split(";")[0] },
  });
  const persistedFees = await persistedFeeData.json();
  assert.equal(persistedFees.feeInvoices.find((invoice) => invoice.id === feeInvoice.id).amountPaise, feeInvoice.amountPaise);
  assert.ok(persistedFees.feePaymentSimulations.some((item) => item.id === simulation.id && item.status === "simulation_only"));
  const returned = await fetch(`${baseUrl}/api/student/loans/${loan.id}/return`, {
    method: "POST",
    headers: { cookie: newStudentCookie.split(";")[0], "content-type": "application/json" },
    body: "{}",
  });
  assert.equal(returned.status, 200);
});
